# Annota — annotation de PDF au stylet (Android)

Application Android légère, sans aucune dépendance externe (Java + API Android natives).

## Fonctions
- **Bibliothèque** : dossiers / sous-dossiers, miniatures, renommer, déplacer, supprimer (appui long).
- **Importer un PDF** (un ou plusieurs) ou créer une **note vierge**. Ouvrir un PDF depuis une autre appli (« Ouvrir avec Annota » / « Partager »).
- **Lecture continue** : toutes les pages à la suite, zoom jusqu'à ×10, texte re-rendu net quand on s'arrête de zoomer.
- **Stylo** : couleur (nuancier complet + code RVB + couleurs prédéfinies), épaisseur, opacité, sensibilité à la pression.
- **Surligneur** : vrai effet surligneur (le texte reste lisible dessous), couleur, épaisseur, opacité.
- **Gomme** : trait entier ou partielle, taille réglable. Bouton du stylet = gomme temporaire.
- **Main** : déplacement avec le stylet.
- **Annuler / rétablir** (+ tap à 2 doigts = annuler), ajout de pages vierges, aller à une page.
- **Export** en PDF annoté (pages PDF en image ~180 dpi, annotations vectorielles).
- 4 couleurs favorites par outil dans la barre (appui long sur une pastille = y enregistrer la couleur actuelle).

## Stylet
- **Rejet de la paume** : seul le stylet écrit. Les doigts servent à naviguer (1 doigt défiler, 2 doigts zoomer), et sont **ignorés** dès que le stylet touche ou **survole** l'écran.
- **Survol** : un curseur montre la taille et la couleur de l'outil quand le stylet approche.
- **Latence** : événements stylet non groupés, tous les points intermédiaires utilisés, prédiction de mouvement (Android 14+), cache GPU des traits, taux de rafraîchissement maximal demandé à l'écran.

## Obtenir l'APK sans ordinateur (GitHub, gratuit)
1. Crée un compte sur github.com puis un nouveau dépôt (bouton « New »), par ex. `annota`.
2. Dans le dépôt : **Add file → Create new file**. Nom : `.github/workflows/build.yml`. Colle le contenu du fichier `build.yml` fourni. **Commit**.
3. **Add file → Upload files** → envoie `Annota.zip` tel quel. **Commit**.
4. Onglet **Actions** : la compilation démarre (~4 min). Une fois verte, onglet **Releases** (page d'accueil du dépôt, à droite) → télécharge `Annota.apk`.
5. Ouvre l'APK sur la tablette → autorise « installer des applis inconnues » pour ton navigateur / gestionnaire de fichiers.

Chaque nouvelle version s'installe par-dessus l'ancienne sans perdre les notes (clé de signature fixe incluse).

## Avec Android Studio
Ouvre le dossier `Annota`, puis *Build → Build APK(s)* (ou `gradle assembleRelease`).

## Où sont mes fichiers ?
Dans le stockage privé de l'appli (`Bibliotheque/`). Chaque document est un dossier `Nom.note` (PDF d'origine intact + `ink.bin` pour les annotations). Désinstaller l'appli supprime les notes : exporte d'abord ce que tu veux garder.
