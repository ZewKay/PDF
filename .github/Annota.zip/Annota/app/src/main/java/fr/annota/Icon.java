package fr.annota;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/** Petites icônes dessinées en code (grille 24×24), pour n'avoir aucune dépendance. */
final class Icon extends Drawable {
    static final int BACK = 0, UNDO = 1, REDO = 2, PEN = 3, HIGHLIGHTER = 4, ERASER = 5, HAND = 6,
            ADD_PAGE = 7, MORE = 8, FOLDER = 9, NEW_FOLDER = 10, NOTE = 11, IMPORT = 12, EXPORT = 13;

    private final int type;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    Icon(int type, int color) {
        this.type = type;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.8f);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(color);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
    }

    void setColor(int c) {
        stroke.setColor(c);
        fill.setColor(c);
        invalidateSelf();
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height()) / 24f;
        c.save();
        c.translate(b.centerX() - 12 * s, b.centerY() - 12 * s);
        c.scale(s, s);
        Path p = path;
        p.rewind();
        switch (type) {
            case BACK:
                p.moveTo(15, 5); p.lineTo(8, 12); p.lineTo(15, 19);
                c.drawPath(p, stroke);
                break;
            case UNDO:
                undoPath(p);
                c.drawPath(p, stroke);
                break;
            case REDO:
                c.save();
                c.scale(-1f, 1f, 12f, 12f);
                undoPath(p);
                c.drawPath(p, stroke);
                c.restore();
                break;
            case PEN:
                p.moveTo(16.5f, 3.5f); p.lineTo(20.5f, 7.5f); p.lineTo(8f, 20f); p.lineTo(3.5f, 20.5f); p.lineTo(4f, 16f); p.close();
                p.moveTo(14f, 6f); p.lineTo(18f, 10f);
                c.drawPath(p, stroke);
                break;
            case HIGHLIGHTER:
                p.moveTo(15, 3); p.lineTo(21, 9); p.lineTo(13, 17); p.lineTo(7, 11); p.close();
                p.moveTo(7, 11); p.lineTo(5, 16); p.lineTo(8, 19); p.lineTo(13, 17);
                c.drawPath(p, stroke);
                p.rewind();
                p.moveTo(5, 16); p.lineTo(8, 19); p.lineTo(3, 21); p.close();
                c.drawPath(p, fill);
                break;
            case ERASER:
                p.moveTo(15, 3.5f); p.lineTo(21, 9.5f); p.lineTo(11.5f, 19); p.lineTo(7.5f, 19); p.lineTo(3, 14.5f); p.close();
                p.moveTo(9, 9.5f); p.lineTo(15, 15.5f);
                p.moveTo(11.5f, 19); p.lineTo(20, 19);
                c.drawPath(p, stroke);
                break;
            case HAND:
                p.moveTo(12, 3); p.lineTo(12, 21);
                p.moveTo(3, 12); p.lineTo(21, 12);
                p.moveTo(9, 6); p.lineTo(12, 3); p.lineTo(15, 6);
                p.moveTo(9, 18); p.lineTo(12, 21); p.lineTo(15, 18);
                p.moveTo(6, 9); p.lineTo(3, 12); p.lineTo(6, 15);
                p.moveTo(18, 9); p.lineTo(21, 12); p.lineTo(18, 15);
                c.drawPath(p, stroke);
                break;
            case ADD_PAGE:
                pagePath(p);
                p.moveTo(12.5f, 11); p.lineTo(12.5f, 18);
                p.moveTo(9, 14.5f); p.lineTo(16, 14.5f);
                c.drawPath(p, stroke);
                break;
            case NOTE:
                pagePath(p);
                p.moveTo(9, 11); p.lineTo(16, 11);
                p.moveTo(9, 14.5f); p.lineTo(16, 14.5f);
                p.moveTo(9, 18); p.lineTo(13, 18);
                c.drawPath(p, stroke);
                break;
            case MORE:
                c.drawCircle(12, 5, 1.8f, fill);
                c.drawCircle(12, 12, 1.8f, fill);
                c.drawCircle(12, 19, 1.8f, fill);
                break;
            case FOLDER: {
                folderPath(p);
                int a = fill.getAlpha();
                fill.setAlpha(a / 4);
                c.drawPath(p, fill);
                fill.setAlpha(a);
                c.drawPath(p, stroke);
                break;
            }
            case NEW_FOLDER:
                folderPath(p);
                p.moveTo(12, 10.5f); p.lineTo(12, 16.5f);
                p.moveTo(9, 13.5f); p.lineTo(15, 13.5f);
                c.drawPath(p, stroke);
                break;
            case IMPORT:
                p.moveTo(4, 15); p.lineTo(4, 20); p.lineTo(20, 20); p.lineTo(20, 15);
                p.moveTo(12, 3); p.lineTo(12, 15);
                p.moveTo(7, 10); p.lineTo(12, 15); p.lineTo(17, 10);
                c.drawPath(p, stroke);
                break;
            case EXPORT:
                p.moveTo(4, 15); p.lineTo(4, 20); p.lineTo(20, 20); p.lineTo(20, 15);
                p.moveTo(12, 15); p.lineTo(12, 3);
                p.moveTo(7, 8); p.lineTo(12, 3); p.lineTo(17, 8);
                c.drawPath(p, stroke);
                break;
            default:
                break;
        }
        c.restore();
    }

    private static void undoPath(Path p) {
        p.moveTo(9, 5); p.lineTo(4, 10); p.lineTo(9, 15);
        p.moveTo(4, 10); p.lineTo(14, 10);
        p.cubicTo(18, 10, 20, 12.5f, 20, 15);
        p.cubicTo(20, 17.5f, 18, 20, 14, 20);
        p.lineTo(11, 20);
    }

    private static void pagePath(Path p) {
        p.moveTo(6, 3); p.lineTo(14, 3); p.lineTo(19, 8); p.lineTo(19, 21); p.lineTo(6, 21); p.close();
    }

    private static void folderPath(Path p) {
        p.moveTo(3, 6); p.lineTo(9, 6); p.lineTo(11, 8); p.lineTo(21, 8); p.lineTo(21, 19); p.lineTo(3, 19); p.close();
    }

    @Override
    public void setAlpha(int alpha) {
        stroke.setAlpha(alpha);
        fill.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        stroke.setColorFilter(cf);
        fill.setColorFilter(cf);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
