package fr.annota;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/** Nuancier complet : carré saturation/luminosité + barre de teinte (toutes les couleurs RVB). */
final class ColorPickerView extends View {
    interface OnColor { void onColor(int rgb); }

    private final float[] hsv = {0f, 0f, 0f};
    private final Paint satPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint huePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF sv = new RectF();
    private final RectF hue = new RectF();
    private final float d;
    private int touching; // 0 rien, 1 carré, 2 teinte
    private float shaderHue = -1f;
    OnColor listener;

    ColorPickerView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(2.5f * d);
        ring.setColor(Color.WHITE);
        ring2.setStyle(Paint.Style.STROKE);
        ring2.setStrokeWidth(1f * d);
        ring2.setColor(0x99000000);
    }

    void setColor(int rgb) {
        Color.colorToHSV(rgb, hsv);
        invalidate();
    }

    int getColor() {
        return Color.HSVToColor(hsv);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float bar = 26 * d, gap = 14 * d;
        sv.set(0, 0, w - bar - gap, h);
        hue.set(w - bar, 0, w, h);
        huePaint.setShader(new LinearGradient(0, hue.top, 0, hue.bottom,
                new int[]{0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF0000},
                null, Shader.TileMode.CLAMP));
        valPaint.setShader(new LinearGradient(0, sv.top, 0, sv.bottom, 0x00000000, 0xFF000000, Shader.TileMode.CLAMP));
        shaderHue = -1f;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (sv.width() <= 0) return;
        if (shaderHue != hsv[0]) {
            shaderHue = hsv[0];
            int pure = Color.HSVToColor(new float[]{hsv[0], 1f, 1f});
            satPaint.setShader(new LinearGradient(sv.left, 0, sv.right, 0, 0xFFFFFFFF, pure, Shader.TileMode.CLAMP));
        }
        float r = 10 * d;
        c.drawRoundRect(sv, r, r, satPaint);
        c.drawRoundRect(sv, r, r, valPaint);
        c.drawRoundRect(hue, r, r, huePaint);

        float x = sv.left + hsv[1] * sv.width();
        float y = sv.top + (1f - hsv[2]) * sv.height();
        c.drawCircle(x, y, 9 * d, ring2);
        c.drawCircle(x, y, 8 * d, ring);

        float hy = hue.top + hsv[0] / 360f * hue.height();
        RectF knob = new RectF(hue.left - 2 * d, hy - 4 * d, hue.right + 2 * d, hy + 4 * d);
        c.drawRoundRect(knob, 4 * d, 4 * d, ring);
        c.drawRoundRect(knob, 4 * d, 4 * d, ring2);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                touching = x >= hue.left - 8 * d ? 2 : 1;
                getParent().requestDisallowInterceptTouchEvent(true);
                // fallthrough
            case MotionEvent.ACTION_MOVE:
                if (touching == 1) {
                    hsv[1] = clamp01((x - sv.left) / sv.width());
                    hsv[2] = 1f - clamp01((y - sv.top) / sv.height());
                } else if (touching == 2) {
                    hsv[0] = clamp01((y - hue.top) / hue.height()) * 359.9f;
                }
                invalidate();
                if (listener != null) listener.onColor(getColor());
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                touching = 0;
                return true;
            default:
                return true;
        }
    }

    private static float clamp01(float v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }
}
