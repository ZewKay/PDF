package fr.annota;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RecordingCanvas;
import android.graphics.RectF;
import android.graphics.RenderNode;
import android.os.Build;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.MotionPredictor;
import android.view.PointerIcon;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.OverScroller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Le cœur de l'appli : affichage continu des pages, zoom, écriture au stylet.
 *
 * Latence : événements stylet non groupés (requestUnbufferedDispatch), tous les points
 * intermédiaires utilisés, prédiction de mouvement (Android 14+), et seul le trait en cours
 * est recalculé à chaque image — les traits déjà posés sont mis en cache GPU (RenderNode).
 *
 * Rejet de la paume : le stylet dessine, les doigts ne dessinent jamais. Les doigts sont
 * ignorés dès que le stylet touche ou survole l'écran.
 */
final class InkView extends View {

    interface Host {
        void onInkChanged();
        void onPageChanged(int current, int total);
        void onTwoFingerTap();
    }

    static final int TOOL_PEN = 0;
    static final int TOOL_HIGHLIGHTER = 1;
    static final int TOOL_ERASER = 2;
    static final int TOOL_HAND = 3;

    private static final float GAP = 18f;
    private static final float MARGIN = 18f;
    private static final long PALM_GUARD_MS = 400;

    // ---- document
    private NoteDoc doc;
    private Ink ink;
    private PageSource src;
    Host host;
    private int pageCount;
    private float[] pageLeft = new float[0], pageTop = new float[0], pageW = new float[0], pageH = new float[0];
    private float docW = 1f, docH = 1f, maxPageW = 1f;

    // ---- transformation : écran = doc * scale + off
    private float scale = 1f, offX, offY, fitScale = 1f;
    private boolean laidOut;

    // ---- réglages des outils (modifiés par l'activité)
    int tool = TOOL_PEN;
    int penColor = 0xFF1A1A1A;
    float penWidth = 1.6f;
    boolean penPressure = true;
    int hlColor = 0x73FFE600;
    float hlWidth = 14f;
    float eraserRadiusPx = 24f;
    boolean eraserPartial = false;
    boolean fingerNav = true;
    boolean stylusButtonEraser = true;
    boolean showHover = true;

    // ---- rendu
    private final Paint pagePaint = new Paint();
    private final Paint borderPaint = new Paint();
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint livePaint = new Paint();
    private final Paint strokePaint = new Paint();
    private final Paint cursorFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cursorRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint cursorRing2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmpRect = new RectF();
    private final RectF tmpRect2 = new RectF();
    private RenderNode[] nodes = new RenderNode[0];
    private boolean[] nodeDirty = new boolean[0];

    // ---- stylet
    private int stylusId = -1;
    private int activeTool = -1;
    private int strokePage = -1, strokeTool, strokeFlags, strokeColor;
    private float strokeWidth;
    private float[] live = new float[3 * 512];
    private int liveN;
    private float lastPressure;
    private final float[] pred = new float[3 * 64];
    private int predN;
    private float[] combo = new float[3 * 640];
    private final Path livePath = new Path();
    private boolean liveActive;
    private Object predictor; // MotionPredictor (Android 14+)
    private boolean predictOk;
    private Ink.Edit eraseEdit;
    private float lastEX, lastEY;
    private float handX, handY;

    // ---- doigts
    private int f1 = -1, f2 = -1;
    private float f1x, f1y, f2x, f2y;
    private boolean fingerBlocked;
    private long twoDownTime;
    private boolean twoMoved;
    private float twoStartDist, twoStartFx, twoStartFy;
    private VelocityTracker velocity;
    private final OverScroller scroller;
    private final float minFling, maxFling, touchSlop;

    // ---- survol
    private boolean hovering, hoverEraser;
    private float hoverX, hoverY;
    private long lastHoverTime, lastPenUpTime;

    private int currentPage = -1;
    private final float density;
    private final Runnable detailTask = this::requestDetails;

    InkView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        ViewConfiguration vc = ViewConfiguration.get(c);
        minFling = vc.getScaledMinimumFlingVelocity();
        maxFling = vc.getScaledMaximumFlingVelocity();
        touchSlop = vc.getScaledTouchSlop();
        scroller = new OverScroller(c);

        pagePaint.setColor(Color.WHITE);
        borderPaint.setColor(0xFFC7C7CC);
        borderPaint.setStyle(Paint.Style.STROKE);
        cursorRing.setStyle(Paint.Style.STROKE);
        cursorRing.setColor(0xCC000000);
        cursorRing.setStrokeWidth(1.2f * density);
        cursorRing2.setStyle(Paint.Style.STROKE);
        cursorRing2.setColor(0xCCFFFFFF);
        cursorRing2.setStrokeWidth(1.2f * density);
        labelPaint.setColor(Color.WHITE);
        labelPaint.setTextSize(13 * density);
        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelBg.setColor(0x99000000);

        if (Build.VERSION.SDK_INT >= 34) {
            try {
                predictor = P34.create(c);
            } catch (Throwable t) {
                predictor = null;
            }
        }
    }

    // =====================================================================================
    // Document & mise en page
    // =====================================================================================

    void setDocument(NoteDoc d, Ink k, PageSource s) {
        doc = d;
        ink = k;
        src = s;
        relayout();
    }

    private void relayout() {
        pageCount = doc.pages.size();
        pageLeft = new float[pageCount];
        pageTop = new float[pageCount];
        pageW = new float[pageCount];
        pageH = new float[pageCount];
        maxPageW = 1f;
        for (NoteDoc.PageSpec p : doc.pages) maxPageW = Math.max(maxPageW, p.w);
        docW = maxPageW + 2 * MARGIN;
        float y = MARGIN;
        for (int i = 0; i < pageCount; i++) {
            NoteDoc.PageSpec p = doc.pages.get(i);
            pageW[i] = p.w;
            pageH[i] = p.h;
            pageLeft[i] = (docW - p.w) / 2f;
            pageTop[i] = y;
            y += p.h + GAP;
        }
        docH = y - GAP + MARGIN;
        ink.ensure(pageCount);
        nodes = Arrays.copyOf(nodes, pageCount);
        boolean[] nd = new boolean[pageCount];
        Arrays.fill(nd, true);
        nodeDirty = nd;
    }

    int pageCount() { return pageCount; }

    private float minScale() { return fitScale * 0.35f; }

    private float maxScale() { return fitScale * 10f; }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w == 0 || h == 0 || doc == null) return;
        float newFit = w / docW;
        if (!laidOut || ow == 0) {
            scale = newFit;
            offX = 0;
            offY = 0;
            laidOut = true;
        } else {
            float z = scale / fitScale;
            float topDoc = -offY / scale;
            float cxDoc = (ow * 0.5f - offX) / scale;
            scale = z * newFit;
            offY = -topDoc * scale;
            offX = w * 0.5f - cxDoc * scale;
        }
        fitScale = newFit;
        if (src != null) src.setBaseScale(Math.min(fitScale, 2048f / maxPageW));
        clamp();
        onTransformChanged();
    }

    private void clamp() {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        float cw = docW * scale, ch = docH * scale;
        offX = cw <= w ? (w - cw) / 2f : Math.max(w - cw, Math.min(0f, offX));
        offY = ch <= h ? 0f : Math.max(h - ch, Math.min(0f, offY));
    }

    private int firstVisible() {
        float docTop = -offY / scale;
        int lo = 0, hi = pageCount - 1, ans = pageCount;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (pageTop[mid] + pageH[mid] >= docTop) {
                ans = mid;
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        }
        return ans;
    }

    private int lastVisible() {
        float docBottom = (getHeight() - offY) / scale;
        int lo = 0, hi = pageCount - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (pageTop[mid] <= docBottom) {
                ans = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return ans;
    }

    /** Page contenant (ou la plus proche de) l'ordonnée y du document. */
    private int pageAtDocY(float y) {
        if (pageCount == 0) return -1;
        int lo = 0, hi = pageCount - 1, i = 0;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (pageTop[mid] <= y) {
                i = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        if (i + 1 < pageCount && y > pageTop[i] + pageH[i]) {
            float dBelow = pageTop[i + 1] - y;
            float dAbove = y - (pageTop[i] + pageH[i]);
            if (dBelow < dAbove) i = i + 1;
        }
        return i;
    }

    // =====================================================================================
    // Dessin
    // =====================================================================================

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(0xFFE5E5EA);
        if (doc == null || pageCount == 0) return;
        int first = firstVisible();
        int last = lastVisible();
        if (src != null) {
            src.setWanted(first, last);
            if (first - 1 >= 0) src.requestBase(first - 1);
            if (last + 1 < pageCount) src.requestBase(last + 1);
        }
        boolean hw = canvas.isHardwareAccelerated();

        canvas.save();
        canvas.translate(offX, offY);
        canvas.scale(scale, scale);
        borderPaint.setStrokeWidth(1f / scale);
        for (int i = first; i <= last && i < pageCount; i++) {
            float L = pageLeft[i], T = pageTop[i], W = pageW[i], H = pageH[i];
            tmpRect.set(L, T, L + W, T + H);
            canvas.drawRect(tmpRect, pagePaint);
            NoteDoc.PageSpec spec = doc.pages.get(i);
            if (spec.pdfIndex >= 0 && src != null) {
                Bitmap b = src.base(i);
                if (b != null) {
                    canvas.drawBitmap(b, null, tmpRect, bmpPaint);
                } else {
                    src.requestBase(i);
                }
                PageSource.Detail d = src.detail(i);
                if (d != null) {
                    tmpRect2.set(L + d.rect.left, T + d.rect.top, L + d.rect.right, T + d.rect.bottom);
                    canvas.drawBitmap(d.bmp, null, tmpRect2, bmpPaint);
                }
            }
            canvas.drawRect(tmpRect, borderPaint);

            canvas.save();
            canvas.translate(L, T);
            if (hw) {
                canvas.drawRenderNode(node(i));
            } else {
                canvas.save();
                canvas.clipRect(0, 0, W, H);
                Stroke.drawAll(canvas, ink.page(i), strokePaint);
                canvas.restore();
            }
            if (liveActive && strokePage == i) canvas.drawPath(livePath, livePaint);
            canvas.restore();
        }
        canvas.restore();

        drawHoverCursor(canvas);
        drawPageLabel(canvas);
    }

    private RenderNode node(int i) {
        RenderNode n = nodes[i];
        if (n == null) {
            n = new RenderNode("ink" + i);
            nodes[i] = n;
            nodeDirty[i] = true;
        }
        if (nodeDirty[i]) {
            n.setPosition(0, 0, (int) Math.ceil(pageW[i]), (int) Math.ceil(pageH[i]));
            RecordingCanvas rc = n.beginRecording();
            try {
                Stroke.drawAll(rc, ink.page(i), strokePaint);
            } finally {
                n.endRecording();
            }
            nodeDirty[i] = false;
        }
        return n;
    }

    private void markDirty(int page) {
        if (page >= 0 && page < nodeDirty.length) nodeDirty[page] = true;
    }

    private void markDirty(Ink.Edit e) {
        for (Stroke s : e.added) markDirty(s.page);
        for (Stroke s : e.removed) markDirty(s.page);
    }

    private void drawHoverCursor(Canvas c) {
        if (!hovering || !showHover || stylusId != -1) return;
        int t = hoverEraser ? TOOL_ERASER : tool;
        if (t == TOOL_PEN || t == TOOL_HIGHLIGHTER) {
            float w = t == TOOL_PEN ? penWidth : hlWidth;
            int col = t == TOOL_PEN ? penColor : hlColor;
            float r = Math.max(2.5f * density, w * scale * 0.5f);
            cursorFill.setColor((col & 0x00FFFFFF) | 0xA0000000);
            c.drawCircle(hoverX, hoverY, r, cursorFill);
            c.drawCircle(hoverX, hoverY, r + cursorRing.getStrokeWidth(), cursorRing2);
        } else if (t == TOOL_ERASER) {
            c.drawCircle(hoverX, hoverY, eraserRadiusPx, cursorRing2);
            c.drawCircle(hoverX, hoverY, eraserRadiusPx + cursorRing.getStrokeWidth(), cursorRing);
        }
    }

    private void drawPageLabel(Canvas c) {
        if (currentPage < 0 || pageCount <= 1) return;
        String s = String.format(Locale.FRANCE, "%d / %d", currentPage + 1, pageCount);
        float tw = labelPaint.measureText(s);
        float cx = getWidth() / 2f;
        float by = getHeight() - 14 * density;
        float ph = 26 * density;
        tmpRect.set(cx - tw / 2 - 12 * density, by - ph, cx + tw / 2 + 12 * density, by);
        c.drawRoundRect(tmpRect, ph / 2, ph / 2, labelBg);
        c.drawText(s, cx, by - ph / 2 - (labelPaint.ascent() + labelPaint.descent()) / 2, labelPaint);
    }

    // =====================================================================================
    // Entrées tactiles
    // =====================================================================================

    private static boolean isStylus(int toolType) {
        return toolType == MotionEvent.TOOL_TYPE_STYLUS || toolType == MotionEvent.TOOL_TYPE_ERASER;
    }

    private boolean penGuard() {
        long now = SystemClock.uptimeMillis();
        return stylusId != -1
                || (hovering && now - lastHoverTime < 1500)
                || now - lastPenUpTime < PALM_GUARD_MS
                || now - lastHoverTime < PALM_GUARD_MS;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (doc == null) return false;
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                if (isStylus(e.getToolType(idx))) {
                    if (stylusId == -1) {
                        stylusId = e.getPointerId(idx);
                        requestUnbufferedDispatch(e);
                        stylusDown(e, idx);
                    }
                } else {
                    fingerDown(e, idx);
                }
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (stylusId != -1) {
                    int si = e.findPointerIndex(stylusId);
                    if (si >= 0) stylusMove(e, si);
                } else {
                    fingerMove(e);
                }
                break;
            }
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_UP: {
                int pid = e.getPointerId(idx);
                if (pid == stylusId) {
                    boolean canceled = Build.VERSION.SDK_INT >= 33
                            && (e.getFlags() & MotionEvent.FLAG_CANCELED) != 0;
                    if (canceled) stylusCancel(); else stylusUp(e, idx);
                    stylusId = -1;
                } else {
                    fingerUp(e, idx);
                }
                if (action == MotionEvent.ACTION_UP) {
                    if (stylusId != -1) { stylusCancel(); stylusId = -1; }
                    resetFingers();
                }
                break;
            }
            case MotionEvent.ACTION_CANCEL: {
                if (stylusId != -1) {
                    stylusCancel();
                    stylusId = -1;
                }
                resetFingers();
                break;
            }
            default:
                break;
        }
        return true;
    }

    // ---------------------------------------------------------------- stylet

    private void stylusDown(MotionEvent e, int idx) {
        cancelFingers();
        scroller.forceFinished(true);
        hovering = false;
        int tt = e.getToolType(idx);
        boolean btn = (e.getButtonState()
                & (MotionEvent.BUTTON_STYLUS_PRIMARY | MotionEvent.BUTTON_STYLUS_SECONDARY)) != 0;
        int t = (tt == MotionEvent.TOOL_TYPE_ERASER || (stylusButtonEraser && btn)) ? TOOL_ERASER : tool;
        activeTool = t;
        float x = e.getX(idx), y = e.getY(idx);
        if (t == TOOL_PEN || t == TOOL_HIGHLIGHTER) {
            beginStroke(e, t, x, y, e.getPressure(idx));
        } else if (t == TOOL_ERASER) {
            eraseEdit = new Ink.Edit();
            lastEX = x;
            lastEY = y;
            eraseAt(x, y);
        } else {
            handX = x;
            handY = y;
            resetVelocity();
            velocity.addMovement(e);
        }
    }

    private void beginStroke(MotionEvent e, int t, float x, float y, float pressure) {
        int p = pageAtDocY((y - offY) / scale);
        if (p < 0) {
            activeTool = -1;
            return;
        }
        strokePage = p;
        if (t == TOOL_PEN) {
            strokeTool = Stroke.PEN;
            strokeFlags = penPressure ? Stroke.FLAG_PRESSURE : 0;
            strokeColor = penColor;
            strokeWidth = penWidth;
        } else {
            strokeTool = Stroke.HIGHLIGHTER;
            strokeFlags = 0;
            strokeColor = hlColor;
            strokeWidth = hlWidth;
        }
        Stroke.setupPaint(livePaint, strokeTool, strokeFlags, strokeColor, strokeWidth);
        liveN = 0;
        predN = 0;
        lastPressure = pressure;
        addLive(x, y, pressure, true);
        liveActive = true;
        predictOk = false;
        if (predictor != null) {
            predictOk = P34.available(predictor, e);
            if (predictOk) P34.record(predictor, e);
        }
        rebuildLive();
        invalidate();
    }

    private void addLive(float sx, float sy, float pr, boolean force) {
        float px = (sx - offX) / scale - pageLeft[strokePage];
        float py = (sy - offY) / scale - pageTop[strokePage];
        pr = lastPressure + (pr - lastPressure) * 0.55f;
        lastPressure = pr;
        if (!force && liveN > 0) {
            float dx = px - live[(liveN - 1) * 3];
            float dy = py - live[(liveN - 1) * 3 + 1];
            float minD = 0.4f / scale; // ~0,4 pixel écran
            if (dx * dx + dy * dy < minD * minD) return;
        }
        if ((liveN + 1) * 3 > live.length) live = Arrays.copyOf(live, live.length * 2);
        live[liveN * 3] = px;
        live[liveN * 3 + 1] = py;
        live[liveN * 3 + 2] = pr;
        liveN++;
    }

    private void addPred(float sx, float sy) {
        if ((predN + 1) * 3 > pred.length) return;
        pred[predN * 3] = (sx - offX) / scale - pageLeft[strokePage];
        pred[predN * 3 + 1] = (sy - offY) / scale - pageTop[strokePage];
        pred[predN * 3 + 2] = lastPressure;
        predN++;
    }

    private void rebuildLive() {
        int total = liveN + predN;
        float[] pts = live;
        if (predN > 0) {
            if (combo.length < total * 3) combo = new float[total * 6];
            System.arraycopy(live, 0, combo, 0, liveN * 3);
            System.arraycopy(pred, 0, combo, liveN * 3, predN * 3);
            pts = combo;
        }
        Stroke.buildPath(livePath, strokeTool, strokeFlags, strokeWidth, pts, total);
    }

    private void stylusMove(MotionEvent e, int si) {
        int t = activeTool;
        int hs = e.getHistorySize();
        if (t == TOOL_PEN || t == TOOL_HIGHLIGHTER) {
            if (!liveActive) return;
            for (int h = 0; h < hs; h++) {
                addLive(e.getHistoricalX(si, h), e.getHistoricalY(si, h), e.getHistoricalPressure(si, h), false);
            }
            addLive(e.getX(si), e.getY(si), e.getPressure(si), false);
            predN = 0;
            if (predictOk) {
                P34.record(predictor, e);
                MotionEvent pe = P34.predict(predictor);
                if (pe != null) {
                    int pi = pe.findPointerIndex(stylusId);
                    if (pi < 0) pi = 0;
                    if (pe.getPointerCount() > pi) {
                        for (int h = 0; h < pe.getHistorySize(); h++) {
                            addPred(pe.getHistoricalX(pi, h), pe.getHistoricalY(pi, h));
                        }
                        addPred(pe.getX(pi), pe.getY(pi));
                    }
                    pe.recycle();
                }
            }
            rebuildLive();
            invalidate();
        } else if (t == TOOL_ERASER) {
            for (int h = 0; h < hs; h++) eraseTo(e.getHistoricalX(si, h), e.getHistoricalY(si, h));
            eraseTo(e.getX(si), e.getY(si));
        } else if (t == TOOL_HAND) {
            float x = e.getX(si), y = e.getY(si);
            offX += x - handX;
            offY += y - handY;
            handX = x;
            handY = y;
            if (velocity != null) velocity.addMovement(e);
            clamp();
            onTransformChanged();
        }
    }

    private void stylusUp(MotionEvent e, int idx) {
        int t = activeTool;
        if (t == TOOL_PEN || t == TOOL_HIGHLIGHTER) {
            if (liveActive) {
                addLive(e.getX(idx), e.getY(idx), e.getPressure(idx), false);
                predN = 0;
                commitStroke();
            }
        } else if (t == TOOL_ERASER) {
            finishErase();
        } else if (t == TOOL_HAND && velocity != null) {
            velocity.addMovement(e);
            velocity.computeCurrentVelocity(1000, maxFling);
            fling(velocity.getXVelocity(stylusId), velocity.getYVelocity(stylusId));
        }
        activeTool = -1;
        lastPenUpTime = SystemClock.uptimeMillis();
    }

    private void stylusCancel() {
        if (activeTool == TOOL_ERASER) finishErase();
        liveActive = false;
        liveN = 0;
        predN = 0;
        livePath.rewind();
        activeTool = -1;
        lastPenUpTime = SystemClock.uptimeMillis();
        invalidate();
    }

    private void commitStroke() {
        liveActive = false;
        if (liveN > 0 && strokePage >= 0 && strokePage < pageCount) {
            float[] pts = Arrays.copyOf(live, liveN * 3);
            Stroke s = new Stroke(strokePage, strokeTool, strokeFlags, strokeColor, strokeWidth, pts, liveN);
            ink.add(s);
            Ink.Edit ed = new Ink.Edit();
            ed.added.add(s);
            ink.push(ed);
            markDirty(strokePage);
            if (host != null) host.onInkChanged();
        }
        livePath.rewind();
        liveN = 0;
        invalidate();
    }

    // ---------------------------------------------------------------- gomme

    private void eraseTo(float x, float y) {
        float dx = x - lastEX, dy = y - lastEY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        float step = Math.max(2f, eraserRadiusPx * 0.5f);
        int steps = (int) Math.ceil(dist / step);
        for (int k = 1; k <= steps; k++) {
            eraseAt(lastEX + dx * k / steps, lastEY + dy * k / steps);
        }
        lastEX = x;
        lastEY = y;
    }

    private void eraseAt(float sx, float sy) {
        if (eraseEdit == null) eraseEdit = new Ink.Edit();
        float dx = (sx - offX) / scale, dy = (sy - offY) / scale;
        float r = eraserRadiusPx / scale;
        int center = pageAtDocY(dy);
        if (center < 0) return;
        for (int i = Math.max(0, center - 1); i <= Math.min(pageCount - 1, center + 1); i++) {
            if (dy + r < pageTop[i] || dy - r > pageTop[i] + pageH[i]) continue;
            float lx = dx - pageLeft[i], ly = dy - pageTop[i];
            ArrayList<Stroke> list = ink.page(i);
            boolean changed = false;
            for (int k = list.size() - 1; k >= 0; k--) {
                Stroke s = list.get(k);
                if (eraserPartial) {
                    List<Stroke> pieces = s.splitOutside(lx, ly, r);
                    if (pieces == null) continue;
                    list.remove(k);
                    recordRemoval(s);
                    for (Stroke pc : pieces) {
                        list.add(pc);
                        eraseEdit.added.add(pc);
                    }
                    changed = true;
                } else if (s.hits(lx, ly, r)) {
                    list.remove(k);
                    recordRemoval(s);
                    changed = true;
                }
            }
            if (changed) {
                markDirty(i);
                invalidate();
            }
        }
    }

    private void recordRemoval(Stroke s) {
        // un morceau créé pendant ce même coup de gomme : on annule simplement son ajout
        if (!eraseEdit.added.remove(s)) eraseEdit.removed.add(s);
    }

    private void finishErase() {
        if (eraseEdit != null && !eraseEdit.isEmpty()) {
            ink.push(eraseEdit);
            if (host != null) host.onInkChanged();
        }
        eraseEdit = null;
    }

    // ---------------------------------------------------------------- doigts

    private void resetVelocity() {
        if (velocity == null) velocity = VelocityTracker.obtain();
        else velocity.clear();
    }

    private void cancelFingers() {
        if (f1 != -1 || f2 != -1) fingerBlocked = true;
        f1 = -1;
        f2 = -1;
    }

    private void resetFingers() {
        f1 = -1;
        f2 = -1;
        fingerBlocked = false;
    }

    private void fingerDown(MotionEvent e, int idx) {
        if (!fingerNav || fingerBlocked) return;
        if (f1 == -1 && f2 == -1 && penGuard()) {
            fingerBlocked = true; // paume posée pendant l'écriture : on ignore tout le geste
            return;
        }
        int id = e.getPointerId(idx);
        if (f1 == -1) {
            f1 = id;
            f1x = e.getX(idx);
            f1y = e.getY(idx);
            scroller.forceFinished(true);
            resetVelocity();
            velocity.addMovement(e);
        } else if (f2 == -1) {
            f2 = id;
            int i1 = e.findPointerIndex(f1);
            if (i1 >= 0) {
                f1x = e.getX(i1);
                f1y = e.getY(i1);
            }
            f2x = e.getX(idx);
            f2y = e.getY(idx);
            twoDownTime = e.getEventTime();
            twoMoved = false;
            twoStartDist = (float) Math.hypot(f2x - f1x, f2y - f1y);
            twoStartFx = (f1x + f2x) / 2f;
            twoStartFy = (f1y + f2y) / 2f;
        }
    }

    private void fingerMove(MotionEvent e) {
        if (fingerBlocked || f1 == -1) return;
        if (velocity != null) velocity.addMovement(e);
        int i1 = e.findPointerIndex(f1);
        if (i1 < 0) return;
        float x1 = e.getX(i1), y1 = e.getY(i1);
        if (f2 != -1) {
            int i2 = e.findPointerIndex(f2);
            if (i2 < 0) return;
            float x2 = e.getX(i2), y2 = e.getY(i2);
            float d = (float) Math.hypot(x2 - x1, y2 - y1);
            float pd = (float) Math.hypot(f2x - f1x, f2y - f1y);
            float fx = (x1 + x2) / 2f, fy = (y1 + y2) / 2f;
            float pfx = (f1x + f2x) / 2f, pfy = (f1y + f2y) / 2f;
            if (pd > 8f && d > 8f) zoomAround(pfx, pfy, d / pd);
            offX += fx - pfx;
            offY += fy - pfy;
            if (Math.abs(d - twoStartDist) > touchSlop
                    || Math.hypot(fx - twoStartFx, fy - twoStartFy) > touchSlop) {
                twoMoved = true;
            }
            f1x = x1; f1y = y1; f2x = x2; f2y = y2;
        } else {
            offX += x1 - f1x;
            offY += y1 - f1y;
            f1x = x1;
            f1y = y1;
        }
        clamp();
        onTransformChanged();
    }

    private void fingerUp(MotionEvent e, int idx) {
        if (fingerBlocked) return;
        int id = e.getPointerId(idx);
        if (id != f1 && id != f2) return;
        if (f2 != -1) {
            if (!twoMoved && e.getEventTime() - twoDownTime < 300 && host != null) {
                host.onTwoFingerTap();
                twoMoved = true;
            }
            if (id == f1) {
                f1 = f2;
                f1x = f2x;
                f1y = f2y;
            }
            f2 = -1;
            resetVelocity();
        } else {
            if (velocity != null) {
                velocity.addMovement(e);
                velocity.computeCurrentVelocity(1000, maxFling);
                fling(velocity.getXVelocity(f1), velocity.getYVelocity(f1));
            }
            f1 = -1;
        }
    }

    private void zoomAround(float fx, float fy, float factor) {
        float ns = Math.max(minScale(), Math.min(maxScale(), scale * factor));
        float real = ns / scale;
        offX = fx - (fx - offX) * real;
        offY = fy - (fy - offY) * real;
        scale = ns;
    }

    private void fling(float vx, float vy) {
        if (Math.hypot(vx, vy) < minFling) {
            onTransformChanged();
            return;
        }
        int w = getWidth(), h = getHeight();
        float cw = docW * scale, ch = docH * scale;
        int minX, maxX, minY, maxY;
        if (cw <= w) { minX = maxX = Math.round((w - cw) / 2f); } else { minX = Math.round(w - cw); maxX = 0; }
        if (ch <= h) { minY = maxY = 0; } else { minY = Math.round(h - ch); maxY = 0; }
        scroller.fling(Math.round(offX), Math.round(offY), Math.round(vx), Math.round(vy), minX, maxX, minY, maxY);
        postInvalidateOnAnimation();
    }

    @Override
    public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            offX = scroller.getCurrX();
            offY = scroller.getCurrY();
            clamp();
            onTransformChanged();
            postInvalidateOnAnimation();
        }
    }

    private void onTransformChanged() {
        invalidate();
        updateCurrentPage();
        removeCallbacks(detailTask);
        postDelayed(detailTask, 160);
    }

    private void updateCurrentPage() {
        if (pageCount == 0 || getHeight() == 0) return;
        int p = pageAtDocY((getHeight() / 2f - offY) / scale);
        if (p != currentPage) {
            currentPage = p;
            if (host != null) host.onPageChanged(p + 1, pageCount);
        }
    }

    /** Re-rend la zone visible en haute définition une fois le geste terminé. */
    private void requestDetails() {
        if (src == null || pageCount == 0 || getWidth() == 0) return;
        if (scale <= src.baseScale * 1.12f) {
            src.clearDetails();
            invalidate();
            return;
        }
        int w = getWidth(), h = getHeight();
        float vl = -offX / scale, vtp = -offY / scale;
        float vr = (w - offX) / scale, vb = (h - offY) / scale;
        float mx = (vr - vl) * 0.12f, my = (vb - vtp) * 0.12f;
        ArrayList<PageSource.DetailReq> reqs = new ArrayList<>();
        int first = firstVisible(), last = lastVisible();
        for (int i = first; i <= last && i < pageCount; i++) {
            NoteDoc.PageSpec spec = doc.pages.get(i);
            if (spec.pdfIndex < 0) continue;
            float L = pageLeft[i], T = pageTop[i];
            RectF r = new RectF(vl - mx - L, vtp - my - T, vr + mx - L, vb + my - T);
            if (!r.intersect(0, 0, pageW[i], pageH[i])) continue;
            reqs.add(new PageSource.DetailReq(i, spec.pdfIndex, r));
        }
        src.requestDetails(reqs, scale);
    }

    // ---------------------------------------------------------------- survol

    @Override
    public boolean onHoverEvent(MotionEvent e) {
        int tt = e.getToolType(0);
        if (!isStylus(tt)) return super.onHoverEvent(e);
        long now = SystemClock.uptimeMillis();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_HOVER_ENTER:
            case MotionEvent.ACTION_HOVER_MOVE:
                hovering = true;
                hoverX = e.getX();
                hoverY = e.getY();
                hoverEraser = tt == MotionEvent.TOOL_TYPE_ERASER
                        || (stylusButtonEraser && (e.getButtonState()
                        & (MotionEvent.BUTTON_STYLUS_PRIMARY | MotionEvent.BUTTON_STYLUS_SECONDARY)) != 0);
                lastHoverTime = now;
                if (f1 != -1) cancelFingers(); // la main se pose : on fige la navigation
                if (showHover) invalidate();
                break;
            case MotionEvent.ACTION_HOVER_EXIT:
                hovering = false;
                lastHoverTime = now;
                invalidate();
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    public PointerIcon onResolvePointerIcon(MotionEvent event, int pointerIndex) {
        if (showHover && tool != TOOL_HAND && isStylus(event.getToolType(pointerIndex))) {
            return PointerIcon.getSystemIcon(getContext(), PointerIcon.TYPE_NULL);
        }
        return super.onResolvePointerIcon(event, pointerIndex);
    }

    // =====================================================================================
    // Actions appelées par l'écran d'édition
    // =====================================================================================

    void undo() {
        Ink.Edit e = ink.undo();
        if (e != null) {
            markDirty(e);
            invalidate();
            if (host != null) host.onInkChanged();
        }
    }

    void redo() {
        Ink.Edit e = ink.redo();
        if (e != null) {
            markDirty(e);
            invalidate();
            if (host != null) host.onInkChanged();
        }
    }

    void addBlankPage() {
        NoteDoc.PageSpec last = doc.pages.get(doc.pages.size() - 1);
        doc.pages.add(new NoteDoc.PageSpec(-1, last.w, last.h));
        relayout();
        scrollToPage(pageCount - 1);
    }

    void scrollToPage(int p) {
        if (p < 0 || p >= pageCount) return;
        scroller.forceFinished(true);
        offY = -(pageTop[p] - MARGIN) * scale;
        clamp();
        onTransformChanged();
    }

    int currentPage() { return Math.max(0, currentPage); }

    void refreshSettings() {
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(detailTask);
        for (RenderNode n : nodes) if (n != null) n.discardDisplayList();
        if (velocity != null) {
            velocity.recycle();
            velocity = null;
        }
    }

    // =====================================================================================
    // Prédiction de mouvement (Android 14+), isolée pour ne pas charger la classe avant.
    // =====================================================================================

    private static final class P34 {
        static Object create(Context c) {
            return new MotionPredictor(c);
        }

        static boolean available(Object p, MotionEvent e) {
            try {
                return ((MotionPredictor) p).isPredictionAvailable(e.getDeviceId(), e.getSource());
            } catch (RuntimeException ex) {
                return false;
            }
        }

        static void record(Object p, MotionEvent e) {
            try {
                ((MotionPredictor) p).record(e);
            } catch (RuntimeException ignored) {
            }
        }

        static MotionEvent predict(Object p) {
            try {
                // base de temps uptime, en nanosecondes ; on prédit ~12 ms en avant
                return ((MotionPredictor) p).predict(SystemClock.uptimeMillis() * 1_000_000L + 12_000_000L);
            } catch (RuntimeException ex) {
                return null;
            }
        }
    }
}
