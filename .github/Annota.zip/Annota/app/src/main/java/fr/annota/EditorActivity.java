package fr.annota;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EditorActivity extends Activity implements InkView.Host {
    static final String EXTRA_DIR = "dir";
    private static final int REQ_EXPORT = 7;

    private static final float PEN_MIN = 0.2f, PEN_MAX = 24f;
    private static final float HL_MIN = 3f, HL_MAX = 48f;
    private static final float ER_MIN = 4f, ER_MAX = 80f; // en dp

    private static final int[] PRESETS = {
            0xFF000000, 0xFF5F6368, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
            0xFF00897B, 0xFF1E88E5, 0xFF3949AB, 0xFF8E24AA, 0xFFD81B60, 0xFF6D4C41,
            0xFFFFE600, 0xFF76FF03, 0xFFFF4081, 0xFF40C4FF, 0xFFFFAB40, 0xFFB388FF
    };

    private NoteDoc doc;
    private Ink ink;
    private PageSource src;
    private InkView view;
    private SharedPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable saveTask = this::saveNow;
    private boolean dirty, thumbDirty;

    // réglages des outils
    private int tool = InkView.TOOL_PEN;
    private int penRgb, penAlpha, hlRgb, hlAlpha;
    private float penWidth, hlWidth, eraserDp;
    private boolean penPressure, eraserPartial, fingerNav, btnEraser, hover;
    private final int[] penFav = new int[4];
    private final int[] hlFav = new int[4];

    // interface
    private ImageButton undoBtn, redoBtn;
    private final ImageButton[] toolBtns = new ImageButton[4];
    private final SwatchView[] swatches = new SwatchView[4];
    private PopupWindow popup;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        String path = getIntent().getStringExtra(EXTRA_DIR);
        if (path == null) { finish(); return; }
        try {
            doc = NoteDoc.load(new File(path));
        } catch (IOException e) {
            Toast.makeText(this, "Impossible d'ouvrir ce document", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        ink = new Ink();
        try {
            ink.load(doc.ink());
        } catch (IOException e) {
            // On ne détruit jamais un fichier illisible : on le met de côté.
            File bak = new File(doc.dir, "ink-illisible-" + System.currentTimeMillis() + ".bin");
            //noinspection ResultOfMethodCallIgnored
            doc.ink().renameTo(bak);
            ink = new Ink();
            Toast.makeText(this, "Annotations illisibles, sauvegardées à part", Toast.LENGTH_LONG).show();
        }
        prefs = getSharedPreferences("annota", MODE_PRIVATE);
        loadPrefs();

        view = new InkView(this);
        view.host = this;
        src = doc.hasPdf() ? new PageSource(doc, () -> view.invalidate()) : null;
        view.setDocument(doc, ink, src);
        applySettings();

        buildUi();
        preferHighRefreshRate();
        updateUndo();
    }

    // =====================================================================================
    // Interface
    // =====================================================================================

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.SURFACE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int pad = Ui.dp(this, 6);
        bar.setPadding(pad, pad, pad, pad);
        bar.setBackgroundColor(Ui.SURFACE);
        bar.setElevation(Ui.dp(this, 3));

        ImageButton back = Ui.iconButton(this, Icon.BACK, "Retour");
        back.setOnClickListener(v -> finish());
        bar.addView(back);

        TextView title = Ui.text(this, doc.name(), 17, Ui.TEXT, true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 8), 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        undoBtn = Ui.iconButton(this, Icon.UNDO, "Annuler");
        undoBtn.setOnClickListener(v -> view.undo());
        bar.addView(undoBtn);
        redoBtn = Ui.iconButton(this, Icon.REDO, "Rétablir");
        redoBtn.setOnClickListener(v -> view.redo());
        bar.addView(redoBtn);

        bar.addView(divider());

        int[] icons = {Icon.PEN, Icon.HIGHLIGHTER, Icon.ERASER, Icon.HAND};
        String[] names = {"Stylo", "Surligneur", "Gomme", "Main (déplacement)"};
        for (int i = 0; i < 4; i++) {
            final int t = i;
            ImageButton b = Ui.iconButton(this, icons[i], names[i]);
            b.setOnClickListener(v -> {
                if (tool == t) showToolOptions(v);
                else selectTool(t);
            });
            b.setOnLongClickListener(v -> {
                selectTool(t);
                showToolOptions(v);
                return true;
            });
            toolBtns[i] = b;
            bar.addView(b);
        }

        bar.addView(divider());

        for (int i = 0; i < 4; i++) {
            final int k = i;
            SwatchView s = new SwatchView(this);
            int sz = Ui.dp(this, 36);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(sz, sz);
            lp.leftMargin = Ui.dp(this, 2);
            s.setLayoutParams(lp);
            s.setOnClickListener(v -> onSwatch(k));
            s.setOnLongClickListener(v -> {
                saveSwatch(k);
                return true;
            });
            s.setContentDescription("Couleur favorite " + (k + 1) + " (appui long : remplacer)");
            s.setTooltipText("Appui long : enregistrer la couleur actuelle ici");
            swatches[i] = s;
            bar.addView(s);
        }

        bar.addView(divider());

        ImageButton add = Ui.iconButton(this, Icon.ADD_PAGE, "Ajouter une page");
        add.setOnClickListener(v -> addPage());
        bar.addView(add);
        ImageButton more = Ui.iconButton(this, Icon.MORE, "Plus");
        more.setOnClickListener(this::showMoreMenu);
        bar.addView(more);

        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(view, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Ui.applyInsets(root);
        Ui.lightBars(this);
        setContentView(root);
        refreshToolbar();
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(0xFFE0E0E5);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 1), Ui.dp(this, 26));
        lp.leftMargin = Ui.dp(this, 6);
        lp.rightMargin = Ui.dp(this, 6);
        d.setLayoutParams(lp);
        return d;
    }

    private void selectTool(int t) {
        tool = t;
        applySettings();
        refreshToolbar();
        savePrefs();
    }

    private void refreshToolbar() {
        for (int i = 0; i < 4; i++) {
            ImageButton b = toolBtns[i];
            if (b == null) continue;
            boolean sel = i == tool;
            Ui.ripple(b, sel ? Ui.ACCENT_SOFT : 0x00000000, Ui.dp(this, 12));
            ((Icon) b.getDrawable()).setColor(sel ? Ui.ACCENT : Ui.TEXT);
        }
        int[] favs = tool == InkView.TOOL_HIGHLIGHTER ? hlFav : penFav;
        int cur = tool == InkView.TOOL_HIGHLIGHTER ? hlRgb : penRgb;
        boolean colorTool = tool == InkView.TOOL_PEN || tool == InkView.TOOL_HIGHLIGHTER;
        for (int i = 0; i < 4; i++) {
            if (swatches[i] == null) continue;
            swatches[i].set(favs[i], colorTool && (favs[i] & 0xFFFFFF) == (cur & 0xFFFFFF));
        }
    }

    private void updateUndo() {
        if (undoBtn == null) return;
        undoBtn.setEnabled(ink.canUndo());
        undoBtn.setAlpha(ink.canUndo() ? 1f : 0.3f);
        redoBtn.setEnabled(ink.canRedo());
        redoBtn.setAlpha(ink.canRedo() ? 1f : 0.3f);
    }

    private void onSwatch(int k) {
        if (tool == InkView.TOOL_HIGHLIGHTER) {
            hlRgb = hlFav[k];
        } else {
            if (tool != InkView.TOOL_PEN) tool = InkView.TOOL_PEN;
            penRgb = penFav[k];
        }
        applySettings();
        refreshToolbar();
        savePrefs();
    }

    private void saveSwatch(int k) {
        if (tool == InkView.TOOL_HIGHLIGHTER) hlFav[k] = hlRgb; else penFav[k] = penRgb;
        refreshToolbar();
        savePrefs();
        Toast.makeText(this, "Couleur enregistrée", Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- options d'outil

    private void showToolOptions(View anchor) {
        dismissPopup();
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        panel.setPadding(p, p, p, p);

        if (tool == InkView.TOOL_PEN || tool == InkView.TOOL_HIGHLIGHTER) {
            final boolean isPen = tool == InkView.TOOL_PEN;
            panel.addView(Ui.text(this, isPen ? "Stylo" : "Surligneur", 17, Ui.TEXT, true));

            final StrokePreview preview = new StrokePreview(this, isPen);

            final ColorPickerView picker = new ColorPickerView(this);
            picker.setColor(isPen ? penRgb : hlRgb);
            LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 190));
            plp.topMargin = Ui.dp(this, 12);
            panel.addView(picker, plp);

            // Code couleur hexadécimal (RVB)
            LinearLayout hexRow = new LinearLayout(this);
            hexRow.setGravity(Gravity.CENTER_VERTICAL);
            hexRow.setPadding(0, Ui.dp(this, 10), 0, 0);
            hexRow.addView(Ui.text(this, "Code RVB  #", 14, Ui.SUB, false));
            final EditText hex = new EditText(this);
            hex.setSingleLine(true);
            hex.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            hex.setText(String.format("%06X", (isPen ? penRgb : hlRgb) & 0xFFFFFF));
            hex.setTextSize(15);
            hexRow.addView(hex, new LinearLayout.LayoutParams(Ui.dp(this, 110), ViewGroup.LayoutParams.WRAP_CONTENT));
            panel.addView(hexRow);

            final boolean[] fromHex = {false};
            picker.listener = rgb -> {
                setToolRgb(isPen, rgb);
                if (!fromHex[0]) hex.setText(String.format("%06X", rgb & 0xFFFFFF));
                preview.invalidate();
            };
            hex.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
                @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
                @Override public void afterTextChanged(Editable s) {
                    String t = s.toString().trim();
                    if (t.startsWith("#")) t = t.substring(1);
                    if (t.length() != 6 || !hex.hasFocus()) return;
                    try {
                        int rgb = 0xFF000000 | Integer.parseInt(t, 16);
                        fromHex[0] = true;
                        picker.setColor(rgb);
                        setToolRgb(isPen, rgb);
                        preview.invalidate();
                        fromHex[0] = false;
                    } catch (NumberFormatException ignored) {
                    }
                }
            });

            // Couleurs prédéfinies
            LinearLayout grid = new LinearLayout(this);
            grid.setOrientation(LinearLayout.VERTICAL);
            grid.setPadding(0, Ui.dp(this, 8), 0, 0);
            LinearLayout row = null;
            for (int i = 0; i < PRESETS.length; i++) {
                if (i % 9 == 0) {
                    row = new LinearLayout(this);
                    grid.addView(row);
                }
                final int col = PRESETS[i];
                SwatchView sv = new SwatchView(this);
                sv.set(col, false);
                int sz = Ui.dp(this, 34);
                row.addView(sv, new LinearLayout.LayoutParams(sz, sz));
                sv.setOnClickListener(v -> {
                    picker.setColor(col);
                    setToolRgb(isPen, col);
                    hex.setText(String.format("%06X", col & 0xFFFFFF));
                    preview.invalidate();
                });
            }
            panel.addView(grid);

            final float min = isPen ? PEN_MIN : HL_MIN, max = isPen ? PEN_MAX : HL_MAX;
            final TextView wLabel = Ui.text(this, "", 14, Ui.SUB, false);
            wLabel.setPadding(0, Ui.dp(this, 12), 0, 0);
            panel.addView(wLabel);
            SeekBar wSeek = new SeekBar(this);
            wSeek.setMax(1000);
            wSeek.setProgress(toProgress(isPen ? penWidth : hlWidth, min, max));
            setWidthLabel(wLabel, isPen ? penWidth : hlWidth);
            wSeek.setOnSeekBarChangeListener(new SeekListener(prog -> {
                float w = fromProgress(prog, min, max);
                if (isPen) penWidth = w; else hlWidth = w;
                setWidthLabel(wLabel, w);
                applySettings();
                preview.invalidate();
            }));
            panel.addView(wSeek);

            final TextView aLabel = Ui.text(this, "", 14, Ui.SUB, false);
            aLabel.setPadding(0, Ui.dp(this, 8), 0, 0);
            panel.addView(aLabel);
            SeekBar aSeek = new SeekBar(this);
            aSeek.setMax(95);
            int alpha = isPen ? penAlpha : hlAlpha;
            aSeek.setProgress(Math.round(alpha * 100f / 255f) - 5);
            aLabel.setText(String.format(Locale.FRANCE, "Opacité : %d %%", Math.round(alpha * 100f / 255f)));
            aSeek.setOnSeekBarChangeListener(new SeekListener(prog -> {
                int pct = prog + 5;
                int a = Math.round(pct * 255f / 100f);
                if (isPen) penAlpha = a; else hlAlpha = a;
                aLabel.setText(String.format(Locale.FRANCE, "Opacité : %d %%", pct));
                applySettings();
                preview.invalidate();
            }));
            panel.addView(aSeek);

            if (isPen) {
                Switch pr = new Switch(this);
                pr.setText("Épaisseur selon la pression");
                pr.setTextSize(14);
                pr.setChecked(penPressure);
                pr.setPadding(0, Ui.dp(this, 8), 0, 0);
                pr.setOnCheckedChangeListener((b, c) -> {
                    penPressure = c;
                    applySettings();
                    preview.invalidate();
                });
                panel.addView(pr);
            }

            LinearLayout.LayoutParams prlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 56));
            prlp.topMargin = Ui.dp(this, 8);
            preview.setBackground(Ui.roundStroke(0xFFFFFFFF, 0xFFE0E0E5, Ui.dp(this, 1), Ui.dp(this, 10)));
            panel.addView(preview, prlp);
        } else if (tool == InkView.TOOL_ERASER) {
            panel.addView(Ui.text(this, "Gomme", 17, Ui.TEXT, true));
            RadioGroup g = new RadioGroup(this);
            g.setPadding(0, Ui.dp(this, 8), 0, 0);
            RadioButton whole = new RadioButton(this);
            whole.setText("Effacer le trait entier");
            whole.setId(View.generateViewId());
            RadioButton part = new RadioButton(this);
            part.setText("Effacer seulement sous la gomme");
            part.setId(View.generateViewId());
            g.addView(whole);
            g.addView(part);
            g.check(eraserPartial ? part.getId() : whole.getId());
            final int partId = part.getId();
            g.setOnCheckedChangeListener((gr, id) -> {
                eraserPartial = id == partId;
                applySettings();
            });
            panel.addView(g);
            final TextView sLabel = Ui.text(this, "", 14, Ui.SUB, false);
            sLabel.setPadding(0, Ui.dp(this, 12), 0, 0);
            sLabel.setText(String.format(Locale.FRANCE, "Taille : %.0f", eraserDp));
            panel.addView(sLabel);
            SeekBar s = new SeekBar(this);
            s.setMax(1000);
            s.setProgress(toProgress(eraserDp, ER_MIN, ER_MAX));
            s.setOnSeekBarChangeListener(new SeekListener(prog -> {
                eraserDp = fromProgress(prog, ER_MIN, ER_MAX);
                sLabel.setText(String.format(Locale.FRANCE, "Taille : %.0f", eraserDp));
                applySettings();
            }));
            panel.addView(s);
            TextView tip = Ui.text(this, "Astuce : le bouton du stylet active la gomme temporairement (si activé dans ⋮).", 13, Ui.SUB, false);
            tip.setPadding(0, Ui.dp(this, 10), 0, 0);
            panel.addView(tip);
        } else {
            panel.addView(Ui.text(this, "Main", 17, Ui.TEXT, true));
            TextView t = Ui.text(this,
                    "Glissez avec le stylet pour vous déplacer dans le document.\n\n"
                            + "Avec les doigts (n'importe quel outil) :\n"
                            + "• 1 doigt : défiler\n• 2 doigts : zoomer / dézoomer\n• tap à 2 doigts : annuler",
                    14, Ui.SUB, false);
            t.setPadding(0, Ui.dp(this, 8), 0, 0);
            panel.addView(t);
        }

        showPopup(panel, anchor, 340);
    }

    private void setWidthLabel(TextView t, float w) {
        t.setText(String.format(Locale.FRANCE, "Épaisseur : %.1f pt", w));
    }

    private void setToolRgb(boolean isPen, int rgb) {
        if (isPen) penRgb = rgb | 0xFF000000; else hlRgb = rgb | 0xFF000000;
        applySettings();
        refreshToolbar();
    }

    private void showPopup(View content, View anchor, int widthDp) {
        ScrollView sc = new ScrollView(this);
        sc.addView(content);
        sc.setBackground(Ui.round(Ui.SURFACE, Ui.dp(this, 16)));
        sc.setClipToOutline(true);
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.8f);
        content.measure(View.MeasureSpec.makeMeasureSpec(Ui.dp(this, widthDp), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int h = Math.min(maxH, content.getMeasuredHeight());
        popup = new PopupWindow(sc, Ui.dp(this, widthDp), h, true);
        popup.setElevation(Ui.dp(this, 12));
        popup.setOutsideTouchable(true);
        popup.setBackgroundDrawable(Ui.round(Ui.SURFACE, Ui.dp(this, 16)));
        popup.setOnDismissListener(this::savePrefs);
        popup.showAsDropDown(anchor, 0, Ui.dp(this, 6));
    }

    private void dismissPopup() {
        if (popup != null && popup.isShowing()) popup.dismiss();
        popup = null;
    }

    // ---------------------------------------------------------------- menu "plus"

    private void showMoreMenu(View anchor) {
        dismissPopup();
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        panel.setPadding(p, p, p, p);

        panel.addView(menuItem(Icon.ADD_PAGE, "Ajouter une page vierge à la fin", v -> {
            dismissPopup();
            addPage();
        }));
        panel.addView(menuItem(Icon.NOTE, "Aller à la page…", v -> {
            dismissPopup();
            goToPage();
        }));
        panel.addView(menuItem(Icon.EXPORT, "Exporter en PDF annoté…", v -> {
            dismissPopup();
            startExport();
        }));

        TextView h = Ui.text(this, "Réglages", 15, Ui.TEXT, true);
        h.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 4));
        panel.addView(h);

        panel.addView(settingSwitch("Navigation avec les doigts (défiler, zoomer, tap à 2 doigts = annuler)", fingerNav,
                c -> fingerNav = c));
        panel.addView(settingSwitch("Bouton du stylet = gomme temporaire", btnEraser, c -> btnEraser = c));
        panel.addView(settingSwitch("Afficher le curseur quand le stylet survole l'écran", hover, c -> hover = c));

        TextView info = Ui.text(this,
                "Rejet de la paume : seul le stylet écrit. Les doigts sont ignorés pendant que le stylet touche ou survole l'écran.",
                12, Ui.SUB, false);
        info.setPadding(0, Ui.dp(this, 10), 0, 0);
        panel.addView(info);

        showPopup(panel, anchor, 360);
    }

    private View menuItem(int icon, String label, View.OnClickListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int pv = Ui.dp(this, 10);
        row.setPadding(Ui.dp(this, 6), pv, Ui.dp(this, 6), pv);
        Ui.ripple(row, 0x00000000, Ui.dp(this, 10));
        android.widget.ImageView iv = new android.widget.ImageView(this);
        iv.setImageDrawable(new Icon(icon, Ui.ACCENT));
        int s = Ui.dp(this, 22);
        row.addView(iv, new LinearLayout.LayoutParams(s, s));
        TextView t = Ui.text(this, label, 15, Ui.TEXT, false);
        t.setPadding(Ui.dp(this, 12), 0, 0, 0);
        row.addView(t);
        row.setOnClickListener(l);
        return row;
    }

    private interface BoolSetter { void set(boolean v); }

    private View settingSwitch(String label, boolean value, BoolSetter setter) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(14);
        s.setChecked(value);
        int pv = Ui.dp(this, 8);
        s.setPadding(0, pv, 0, pv);
        s.setOnCheckedChangeListener((b, c) -> {
            setter.set(c);
            applySettings();
            savePrefs();
        });
        return s;
    }

    private void addPage() {
        view.addBlankPage();
        io.execute(() -> {
            try {
                doc.saveInfo();
            } catch (IOException e) {
                main.post(() -> Toast.makeText(this, "Erreur d'enregistrement", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void goToPage() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("1 – " + view.pageCount());
        FrameLayout f = new FrameLayout(this);
        int p = Ui.dp(this, 20);
        f.setPadding(p, Ui.dp(this, 8), p, 0);
        f.addView(et);
        new AlertDialog.Builder(this)
                .setTitle("Aller à la page")
                .setView(f)
                .setPositiveButton("OK", (d, w) -> {
                    try {
                        view.scrollToPage(Integer.parseInt(et.getText().toString().trim()) - 1);
                    } catch (NumberFormatException ignored) {
                    }
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    // ---------------------------------------------------------------- export

    private void startExport() {
        saveNow();
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_TITLE, doc.name() + " (annoté).pdf");
        try {
            startActivityForResult(i, REQ_EXPORT);
        } catch (Exception e) {
            Toast.makeText(this, "Aucune application pour enregistrer le fichier", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_EXPORT || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        final ArrayList<Stroke> snap = ink.snapshot();
        Toast.makeText(this, "Export en cours…", Toast.LENGTH_SHORT).show();
        io.execute(() -> {
            String msg;
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new IOException("destination illisible");
                DocIO.export(doc, snap, out);
                msg = "PDF exporté ✔";
            } catch (Exception | OutOfMemoryError e) {
                msg = "Échec de l'export : " + e.getMessage();
            }
            final String m = msg;
            main.post(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show());
        });
    }

    // =====================================================================================
    // InkView.Host
    // =====================================================================================

    @Override
    public void onInkChanged() {
        dirty = true;
        thumbDirty = true;
        main.removeCallbacks(saveTask);
        main.postDelayed(saveTask, 1500);
        updateUndo();
    }

    @Override
    public void onPageChanged(int current, int total) {
    }

    @Override
    public void onTwoFingerTap() {
        view.undo();
    }

    // =====================================================================================
    // Sauvegarde & cycle de vie
    // =====================================================================================

    private void saveNow() {
        main.removeCallbacks(saveTask);
        if (!dirty || ink == null) return;
        dirty = false;
        final ArrayList<Stroke> snap = ink.snapshot();
        final File f = doc.ink();
        io.execute(() -> {
            try {
                Ink.save(f, snap);
            } catch (IOException e) {
                main.post(() -> {
                    dirty = true;
                    Toast.makeText(this, "Erreur d'enregistrement des annotations", Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (doc == null) return;
        saveNow();
        savePrefs();
        if (thumbDirty) {
            thumbDirty = false;
            final ArrayList<Stroke> page0 = new ArrayList<>(ink.page(0));
            io.execute(() -> DocIO.writeThumb(doc, page0));
        }
    }

    @Override
    protected void onDestroy() {
        dismissPopup();
        if (src != null) src.close();
        io.shutdown(); // les tâches en attente (sauvegarde) se terminent quand même
        super.onDestroy();
    }

    /** Demande au système le taux de rafraîchissement le plus élevé (ex. 144 Hz) : moins de latence. */
    private void preferHighRefreshRate() {
        try {
            Display d = getDisplay();
            if (d == null) return;
            Display.Mode cur = d.getMode();
            Display.Mode best = cur;
            for (Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() == cur.getPhysicalWidth()
                        && m.getPhysicalHeight() == cur.getPhysicalHeight()
                        && m.getRefreshRate() > best.getRefreshRate()) {
                    best = m;
                }
            }
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredDisplayModeId = best.getModeId();
            getWindow().setAttributes(lp);
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- préférences

    private void loadPrefs() {
        SharedPreferences p = prefs;
        tool = p.getInt("tool", InkView.TOOL_PEN);
        penRgb = p.getInt("pen_rgb", 0xFF1A1A1A);
        penAlpha = p.getInt("pen_alpha", 255);
        penWidth = p.getFloat("pen_width", 1.6f);
        penPressure = p.getBoolean("pen_pressure", true);
        hlRgb = p.getInt("hl_rgb", 0xFFFFE600);
        hlAlpha = p.getInt("hl_alpha", 115);
        hlWidth = p.getFloat("hl_width", 14f);
        eraserDp = p.getFloat("er_dp", 14f);
        eraserPartial = p.getBoolean("er_partial", false);
        fingerNav = p.getBoolean("nav_fingers", true);
        btnEraser = p.getBoolean("btn_eraser", true);
        hover = p.getBoolean("hover", true);
        int[] dp = {0xFF1A1A1A, 0xFFE53935, 0xFF1E88E5, 0xFF43A047};
        int[] dh = {0xFFFFE600, 0xFF76FF03, 0xFFFF4081, 0xFF40C4FF};
        for (int i = 0; i < 4; i++) {
            penFav[i] = p.getInt("pen_fav" + i, dp[i]);
            hlFav[i] = p.getInt("hl_fav" + i, dh[i]);
        }
    }

    private void savePrefs() {
        if (prefs == null) return;
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("tool", tool);
        e.putInt("pen_rgb", penRgb);
        e.putInt("pen_alpha", penAlpha);
        e.putFloat("pen_width", penWidth);
        e.putBoolean("pen_pressure", penPressure);
        e.putInt("hl_rgb", hlRgb);
        e.putInt("hl_alpha", hlAlpha);
        e.putFloat("hl_width", hlWidth);
        e.putFloat("er_dp", eraserDp);
        e.putBoolean("er_partial", eraserPartial);
        e.putBoolean("nav_fingers", fingerNav);
        e.putBoolean("btn_eraser", btnEraser);
        e.putBoolean("hover", hover);
        for (int i = 0; i < 4; i++) {
            e.putInt("pen_fav" + i, penFav[i]);
            e.putInt("hl_fav" + i, hlFav[i]);
        }
        e.apply();
    }

    private void applySettings() {
        if (view == null) return;
        view.tool = tool;
        view.penColor = (penAlpha << 24) | (penRgb & 0xFFFFFF);
        view.penWidth = penWidth;
        view.penPressure = penPressure;
        view.hlColor = (hlAlpha << 24) | (hlRgb & 0xFFFFFF);
        view.hlWidth = hlWidth;
        view.eraserRadiusPx = eraserDp * getResources().getDisplayMetrics().density;
        view.eraserPartial = eraserPartial;
        view.fingerNav = fingerNav;
        view.stylusButtonEraser = btnEraser;
        view.showHover = hover;
        view.refreshSettings();
    }

    static float fromProgress(int p, float min, float max) {
        return (float) (min * Math.pow(max / min, p / 1000.0));
    }

    static int toProgress(float v, float min, float max) {
        double t = Math.log(Math.max(min, Math.min(max, v)) / min) / Math.log(max / min);
        return (int) Math.round(t * 1000);
    }

    // =====================================================================================
    // Petites vues
    // =====================================================================================

    private interface IntCallback { void on(int v); }

    private static final class SeekListener implements SeekBar.OnSeekBarChangeListener {
        private final IntCallback cb;

        SeekListener(IntCallback cb) { this.cb = cb; }

        @Override public void onProgressChanged(SeekBar s, int p, boolean user) { if (user) cb.on(p); }
        @Override public void onStartTrackingTouch(SeekBar s) {}
        @Override public void onStopTrackingTouch(SeekBar s) {}
    }

    /** Pastille de couleur ronde. */
    static final class SwatchView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean selected;

        SwatchView(Context c) {
            super(c);
            float d = c.getResources().getDisplayMetrics().density;
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(2.5f * d);
            ring.setColor(Ui.ACCENT);
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(1f * d);
            edge.setColor(0x33000000);
            setClickable(true);
        }

        void set(int color, boolean sel) {
            fill.setColor(color | 0xFF000000);
            selected = sel;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - ring.getStrokeWidth() * 1.6f;
            c.drawCircle(cx, cy, r, fill);
            c.drawCircle(cx, cy, r, edge);
            if (selected) c.drawCircle(cx, cy, r + ring.getStrokeWidth(), ring);
        }
    }

    /** Aperçu du trait avec les réglages actuels. */
    private final class StrokePreview extends View {
        private final boolean pen;
        private final Paint paint = new Paint();
        private final Path path = new Path();

        StrokePreview(Context c, boolean pen) {
            super(c);
            this.pen = pen;
        }

        @Override
        protected void onDraw(Canvas c) {
            float d = getResources().getDisplayMetrics().density;
            float scale = 1.4f * d; // points → pixels pour l'aperçu
            int n = 40;
            float[] pts = new float[n * 3];
            float w = getWidth() / scale, h = getHeight() / scale;
            for (int i = 0; i < n; i++) {
                float t = i / (float) (n - 1);
                pts[i * 3] = w * 0.08f + t * w * 0.84f;
                pts[i * 3 + 1] = h / 2f + (float) Math.sin(t * Math.PI * 2) * h * 0.22f;
                pts[i * 3 + 2] = 0.35f + 0.65f * (float) Math.sin(t * Math.PI);
            }
            int toolType = pen ? Stroke.PEN : Stroke.HIGHLIGHTER;
            int flags = pen && penPressure ? Stroke.FLAG_PRESSURE : 0;
            int color = pen ? (penAlpha << 24) | (penRgb & 0xFFFFFF) : (hlAlpha << 24) | (hlRgb & 0xFFFFFF);
            float width = pen ? penWidth : hlWidth;
            Stroke.buildPath(path, toolType, flags, width, pts, n);
            Stroke.setupPaint(paint, toolType, flags, color, width);
            c.save();
            c.scale(scale, scale);
            if (!pen) {
                Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
                tp.setColor(Color.DKGRAY);
                tp.setTextSize(h * 0.32f);
                c.drawText("Texte du cours surligné", w * 0.08f, h * 0.6f, tp);
            }
            c.drawPath(path, paint);
            c.restore();
        }
    }
}
