package fr.annota;

import android.graphics.BlendMode;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Un trait d'encre, immuable une fois créé. Coordonnées en points PDF (1/72 pouce),
 * relatives au coin haut-gauche de sa page. Points stockés en triplets (x, y, pression).
 */
final class Stroke {
    static final int PEN = 0;
    static final int HIGHLIGHTER = 1;
    static final int FLAG_PRESSURE = 1;

    final int page;
    final int tool;
    final int flags;
    final int color;   // ARGB (l'alpha = opacité)
    final float width; // en points
    final float[] pts;
    final int n;
    final RectF bounds = new RectF();
    final Path path = new Path();

    Stroke(int page, int tool, int flags, int color, float width, float[] pts, int n) {
        this.page = page;
        this.tool = tool;
        this.flags = flags;
        this.color = color;
        this.width = width;
        this.pts = pts;
        this.n = n;
        computeBounds();
        buildPath(path, tool, flags, width, pts, n);
    }

    private void computeBounds() {
        if (n == 0) { bounds.setEmpty(); return; }
        float l = pts[0], t = pts[1], r = l, b = t;
        for (int i = 1; i < n; i++) {
            float x = pts[i * 3], y = pts[i * 3 + 1];
            if (x < l) l = x; if (x > r) r = x;
            if (y < t) t = y; if (y > b) b = y;
        }
        float h = width * 0.75f + 1f;
        bounds.set(l - h, t - h, r + h, b + h);
    }

    boolean usesOutline() {
        return tool == PEN && (flags & FLAG_PRESSURE) != 0;
    }

    // ------------------------------------------------------------------ dessin

    static boolean usesOutline(int tool, int flags) {
        return tool == PEN && (flags & FLAG_PRESSURE) != 0;
    }

    static void setupPaint(Paint p, int tool, int flags, int color, float width) {
        p.reset();
        p.setAntiAlias(true);
        p.setColor(color);
        if (usesOutline(tool, flags)) {
            p.setStyle(Paint.Style.FILL);
        } else {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(width);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeCap(tool == HIGHLIGHTER ? Paint.Cap.SQUARE : Paint.Cap.ROUND);
        }
        if (tool == HIGHLIGHTER) {
            // Effet "vrai surligneur" : le texte noir reste noir sous la couleur.
            p.setBlendMode(BlendMode.MULTIPLY);
        }
    }

    void setupPaint(Paint p) {
        setupPaint(p, tool, flags, color, width);
    }

    static void buildPath(Path out, int tool, int flags, float width, float[] p, int n) {
        out.rewind();
        if (n <= 0) return;
        if (usesOutline(tool, flags)) {
            buildOutline(out, width, p, n);
        } else {
            buildCenterLine(out, p, n);
        }
    }

    /** Ligne centrale lissée (courbes quadratiques entre les milieux). */
    private static void buildCenterLine(Path out, float[] p, int n) {
        out.moveTo(p[0], p[1]);
        if (n == 1) {
            out.lineTo(p[0] + 0.01f, p[1] + 0.01f);
            return;
        }
        if (n == 2) {
            out.lineTo(p[3], p[4]);
            return;
        }
        for (int i = 1; i < n - 1; i++) {
            float x = p[i * 3], y = p[i * 3 + 1];
            float nx = p[(i + 1) * 3], ny = p[(i + 1) * 3 + 1];
            out.quadTo(x, y, (x + nx) * 0.5f, (y + ny) * 0.5f);
        }
        out.lineTo(p[(n - 1) * 3], p[(n - 1) * 3 + 1]);
    }

    static float radius(float width, float pressure) {
        if (pressure > 1f) pressure = 1f;
        if (pressure < 0f) pressure = 0f;
        float r = width * 0.5f * (0.25f + 0.75f * pressure);
        return Math.max(r, 0.12f);
    }

    /**
     * Contour à épaisseur variable (pression). Union de trapèzes + disques, tous orientés
     * dans le même sens : avec la règle de remplissage WINDING, aucun "trou" possible.
     */
    private static void buildOutline(Path out, float width, float[] p, int n) {
        out.setFillType(Path.FillType.WINDING);
        float pdx = 0, pdy = 0, plen = 0;
        boolean hasPrev = false;
        for (int i = 0; i < n - 1; i++) {
            float x0 = p[i * 3], y0 = p[i * 3 + 1], r0 = radius(width, p[i * 3 + 2]);
            float x1 = p[(i + 1) * 3], y1 = p[(i + 1) * 3 + 1], r1 = radius(width, p[(i + 1) * 3 + 2]);
            float dx = x1 - x0, dy = y1 - y0;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 1e-4f) continue;
            float nx = -dy / len, ny = dx / len;
            out.moveTo(x0 + nx * r0, y0 + ny * r0);
            out.lineTo(x0 - nx * r0, y0 - ny * r0);
            out.lineTo(x1 - nx * r1, y1 - ny * r1);
            out.lineTo(x1 + nx * r1, y1 + ny * r1);
            out.close();
            if (!hasPrev) {
                out.addCircle(x0, y0, r0, Path.Direction.CW);
            } else {
                // disque de jointure seulement si l'angle laisserait une encoche visible
                float cos = (dx * pdx + dy * pdy) / (len * plen);
                if ((1f - cos) * r0 * r0 > 0.004f) out.addCircle(x0, y0, r0, Path.Direction.CW);
            }
            pdx = dx; pdy = dy; plen = len;
            hasPrev = true;
        }
        int l = n - 1;
        out.addCircle(p[l * 3], p[l * 3 + 1], radius(width, p[l * 3 + 2]), Path.Direction.CW);
    }

    /** Dessin logiciel d'une liste de traits (surligneur dessous, stylo dessus). */
    static void drawAll(Canvas c, List<Stroke> strokes, Paint tmp) {
        for (int pass = 0; pass < 2; pass++) {
            int wanted = pass == 0 ? HIGHLIGHTER : PEN;
            for (int i = 0, s = strokes.size(); i < s; i++) {
                Stroke st = strokes.get(i);
                if (st.tool != wanted) continue;
                st.setupPaint(tmp);
                c.drawPath(st.path, tmp);
            }
        }
    }

    // ------------------------------------------------------------------ gomme

    private static float segDist2(float px, float py, float x0, float y0, float x1, float y1) {
        float dx = x1 - x0, dy = y1 - y0;
        float l2 = dx * dx + dy * dy;
        float t = l2 > 0 ? ((px - x0) * dx + (py - y0) * dy) / l2 : 0f;
        if (t < 0) t = 0; else if (t > 1) t = 1;
        float cx = x0 + t * dx - px, cy = y0 + t * dy - py;
        return cx * cx + cy * cy;
    }

    /** Le cercle (x, y, r) touche-t-il ce trait ? */
    boolean hits(float x, float y, float r) {
        if (x < bounds.left - r || x > bounds.right + r || y < bounds.top - r || y > bounds.bottom + r) return false;
        float rr = r + width * 0.5f;
        float rr2 = rr * rr;
        if (n == 1) {
            float dx = pts[0] - x, dy = pts[1] - y;
            return dx * dx + dy * dy <= rr2;
        }
        for (int i = 0; i < n - 1; i++) {
            if (segDist2(x, y, pts[i * 3], pts[i * 3 + 1], pts[(i + 1) * 3], pts[(i + 1) * 3 + 1]) <= rr2) return true;
        }
        return false;
    }

    /**
     * Gomme partielle : renvoie les morceaux restants hors du cercle,
     * ou null si le trait n'est pas touché.
     */
    List<Stroke> splitOutside(float x, float y, float r) {
        if (!hits(x, y, r)) return null;
        float r2 = r * r;
        ArrayList<Stroke> pieces = new ArrayList<>();
        float[] buf = new float[n * 3];
        int bn = 0;
        boolean touched = false;
        for (int i = 0; i < n; i++) {
            float px = pts[i * 3], py = pts[i * 3 + 1];
            float dx = px - x, dy = py - y;
            boolean inside = dx * dx + dy * dy <= r2;
            if (inside) {
                touched = true;
                bn = flush(pieces, buf, bn);
                continue;
            }
            buf[bn * 3] = px; buf[bn * 3 + 1] = py; buf[bn * 3 + 2] = pts[i * 3 + 2];
            bn++;
            // segment qui traverse le cercle sans point à l'intérieur → coupure
            if (i < n - 1) {
                float nx = pts[(i + 1) * 3], ny = pts[(i + 1) * 3 + 1];
                float ndx = nx - x, ndy = ny - y;
                boolean nextInside = ndx * ndx + ndy * ndy <= r2;
                if (!nextInside && segDist2(x, y, px, py, nx, ny) <= r2) {
                    touched = true;
                    bn = flush(pieces, buf, bn);
                }
            }
        }
        // Touché seulement par l'épaisseur du trait (aucun point dans le cercle) :
        // la liste vide signifie "supprimer le trait entier".
        if (!touched) return pieces;
        flush(pieces, buf, bn);
        return pieces;
    }

    private int flush(List<Stroke> out, float[] buf, int bn) {
        if (bn >= 2) {
            float[] copy = new float[bn * 3];
            System.arraycopy(buf, 0, copy, 0, bn * 3);
            out.add(new Stroke(page, tool, flags, color, width, copy, bn));
        }
        return 0;
    }

    // ------------------------------------------------------------------ fichier

    void write(DataOutputStream out) throws IOException {
        out.writeInt(page);
        out.writeByte(tool);
        out.writeByte(flags);
        out.writeInt(color);
        out.writeFloat(width);
        out.writeInt(n);
        for (int i = 0; i < n * 3; i++) out.writeFloat(pts[i]);
    }

    static Stroke read(DataInputStream in) throws IOException {
        int page = in.readInt();
        int tool = in.readByte();
        int flags = in.readByte();
        int color = in.readInt();
        float width = in.readFloat();
        int n = in.readInt();
        if (n < 0 || n > 2_000_000 || page < 0) throw new IOException("fichier corrompu");
        float[] p = new float[n * 3];
        for (int i = 0; i < n * 3; i++) p[i] = in.readFloat();
        return new Stroke(page, tool, flags, color, width, p, n);
    }
}
