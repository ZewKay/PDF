package fr.annota;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/** Import de PDF, miniatures et export. Toujours appelé hors du thread principal. */
final class DocIO {
    static final int THUMB_W = 360;

    private DocIO() {}

    static String queryName(Context c, Uri uri) {
        String name = null;
        try (Cursor cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) name = cur.getString(0);
        } catch (Exception ignored) {
        }
        if (name == null) name = uri.getLastPathSegment();
        if (name == null) name = "Document";
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        if (name.toLowerCase().endsWith(".pdf")) name = name.substring(0, name.length() - 4);
        return name;
    }

    /** Copie le PDF dans la bibliothèque et crée la note correspondante. */
    static File importPdf(Context c, Uri uri, File parent) throws IOException {
        String name = queryName(c, uri);
        File dir = NoteDoc.uniqueChild(parent, name, NoteDoc.EXT);
        if (!dir.mkdirs()) throw new IOException("impossible de créer le dossier");
        try {
            NoteDoc d = new NoteDoc(dir);
            try (InputStream in = c.getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(d.pdf())) {
                if (in == null) throw new IOException("fichier illisible");
                byte[] buf = new byte[1 << 16];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            }
            ParcelFileDescriptor pfd = ParcelFileDescriptor.open(d.pdf(), ParcelFileDescriptor.MODE_READ_ONLY);
            PdfRenderer renderer = null;
            try {
                renderer = new PdfRenderer(pfd);
                int count = renderer.getPageCount();
                for (int i = 0; i < count; i++) {
                    PdfRenderer.Page p = renderer.openPage(i);
                    d.pages.add(new NoteDoc.PageSpec(i, p.getWidth(), p.getHeight()));
                    p.close();
                }
                if (d.pages.isEmpty()) throw new IOException("PDF vide");
                Bitmap thumb = renderThumb(renderer, d, new ArrayList<>());
                saveThumb(thumb, d.thumb());
            } finally {
                if (renderer != null) renderer.close();
                pfd.close();
            }
            d.saveInfo();
            return dir;
        } catch (SecurityException e) {
            NoteDoc.deleteRecursive(dir);
            throw new IOException("PDF protégé par mot de passe");
        } catch (IOException | RuntimeException e) {
            NoteDoc.deleteRecursive(dir);
            throw new IOException(e.getMessage() != null ? e.getMessage() : "PDF illisible");
        }
    }

    /** Miniature de la première page + annotations de la première page. */
    static Bitmap renderThumb(PdfRenderer renderer, NoteDoc d, List<Stroke> page0) {
        NoteDoc.PageSpec spec = d.pages.get(0);
        float s = THUMB_W / spec.w;
        int th = Math.max(1, Math.round(spec.h * s));
        Bitmap b = Bitmap.createBitmap(THUMB_W, th, Bitmap.Config.ARGB_8888);
        b.eraseColor(Color.WHITE);
        if (renderer != null && spec.pdfIndex >= 0 && spec.pdfIndex < renderer.getPageCount()) {
            PdfRenderer.Page p = renderer.openPage(spec.pdfIndex);
            try {
                p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            } finally {
                p.close();
            }
        }
        if (!page0.isEmpty()) {
            Canvas c = new Canvas(b);
            c.scale(s, s);
            Stroke.drawAll(c, page0, new Paint());
        }
        return b;
    }

    static void saveThumb(Bitmap b, File f) throws IOException {
        File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            b.compress(Bitmap.CompressFormat.PNG, 100, out);
        }
        if (!tmp.renameTo(f)) throw new IOException("miniature");
    }

    /** Régénère la miniature (appelé à la fermeture d'un document). */
    static void writeThumb(NoteDoc d, List<Stroke> page0) {
        ParcelFileDescriptor pfd = null;
        PdfRenderer r = null;
        try {
            if (d.hasPdf()) {
                pfd = ParcelFileDescriptor.open(d.pdf(), ParcelFileDescriptor.MODE_READ_ONLY);
                r = new PdfRenderer(pfd);
            }
            saveThumb(renderThumb(r, d, page0), d.thumb());
        } catch (Exception ignored) {
        } finally {
            try { if (r != null) r.close(); } catch (Exception ignored) {}
            try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
        }
    }

    static ArrayList<Stroke> loadStrokes(NoteDoc d) {
        Ink ink = new Ink();
        try {
            ink.load(d.ink());
        } catch (IOException ignored) {
        }
        return ink.snapshot();
    }

    /**
     * Exporte le document annoté en PDF. Les pages PDF sont rendues en image (≈ 180 dpi),
     * les annotations restent vectorielles.
     */
    static void export(NoteDoc d, List<Stroke> all, OutputStream out) throws IOException {
        int n = d.pages.size();
        ArrayList<ArrayList<Stroke>> byPage = new ArrayList<>();
        for (int i = 0; i < n; i++) byPage.add(new ArrayList<>());
        for (Stroke s : all) if (s.page < n) byPage.get(s.page).add(s);

        ParcelFileDescriptor pfd = null;
        PdfRenderer r = null;
        PdfDocument pd = new PdfDocument();
        try {
            if (d.hasPdf()) {
                pfd = ParcelFileDescriptor.open(d.pdf(), ParcelFileDescriptor.MODE_READ_ONLY);
                r = new PdfRenderer(pfd);
            }
            Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
            Paint tmp = new Paint();
            for (int i = 0; i < n; i++) {
                NoteDoc.PageSpec spec = d.pages.get(i);
                int pw = Math.max(1, Math.round(spec.w));
                int ph = Math.max(1, Math.round(spec.h));
                PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(pw, ph, i + 1).create();
                PdfDocument.Page page = pd.startPage(info);
                Canvas c = page.getCanvas();
                c.drawColor(Color.WHITE);
                if (r != null && spec.pdfIndex >= 0 && spec.pdfIndex < r.getPageCount()) {
                    float s = 2.5f;
                    Bitmap b = Bitmap.createBitmap(Math.round(spec.w * s), Math.round(spec.h * s), Bitmap.Config.ARGB_8888);
                    b.eraseColor(Color.WHITE);
                    PdfRenderer.Page p = r.openPage(spec.pdfIndex);
                    try {
                        p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
                    } finally {
                        p.close();
                    }
                    c.drawBitmap(b, null, new RectF(0, 0, spec.w, spec.h), bmpPaint);
                }
                c.save();
                c.clipRect(0, 0, spec.w, spec.h);
                Stroke.drawAll(c, byPage.get(i), tmp);
                c.restore();
                pd.finishPage(page);
            }
            pd.writeTo(out);
        } finally {
            pd.close();
            try { if (r != null) r.close(); } catch (Exception ignored) {}
            try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
        }
    }
}
