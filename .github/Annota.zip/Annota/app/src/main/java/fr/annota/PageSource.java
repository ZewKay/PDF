package fr.annota;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.util.LruCache;
import android.util.SparseArray;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Rendu des pages PDF sur un thread dédié (PdfRenderer n'accepte qu'un thread).
 *  - "base" : chaque page rendue une fois à la résolution de l'écran (zoom 100 %), en cache.
 *    Pendant un zoom/défilement on étire ces images : c'est instantané.
 *  - "détail" : quand on est zoomé et immobile, seule la zone visible est re-rendue
 *    à la résolution exacte, pour un texte net.
 */
final class PageSource {
    interface Listener { void onRendered(); }

    static final class Detail {
        final int page;
        final RectF rect; // zone couverte, en points, relative à la page
        final Bitmap bmp;

        Detail(int page, RectF rect, Bitmap bmp) {
            this.page = page;
            this.rect = rect;
            this.bmp = bmp;
        }
    }

    static final class DetailReq {
        final int page;
        final int pdfIndex;
        final RectF rect;

        DetailReq(int page, int pdfIndex, RectF rect) {
            this.page = page;
            this.pdfIndex = pdfIndex;
            this.rect = rect;
        }
    }

    private final NoteDoc doc;
    private final Listener listener;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<Integer, Bitmap> base;
    private final HashSet<Integer> pending = new HashSet<>();
    private final HashSet<Integer> failed = new HashSet<>();
    private final SparseArray<Detail> details = new SparseArray<>();

    // utilisés uniquement sur le thread de rendu
    private PdfRenderer renderer;
    private ParcelFileDescriptor pfd;

    private volatile int wantFrom = 0, wantTo = -1;
    private volatile int detailGen = 0;
    private volatile float baseScaleV = 1f;
    float baseScale = 1f;
    private volatile boolean closed;

    PageSource(NoteDoc doc, Listener listener) {
        this.doc = doc;
        this.listener = listener;
        long max = Runtime.getRuntime().maxMemory();
        int cacheBytes = (int) Math.min(max / 3, 320L * 1024 * 1024);
        base = new LruCache<Integer, Bitmap>(cacheBytes) {
            @Override
            protected int sizeOf(Integer key, Bitmap value) {
                return value.getByteCount();
            }
        };
        exec.execute(() -> {
            try {
                pfd = ParcelFileDescriptor.open(doc.pdf(), ParcelFileDescriptor.MODE_READ_ONLY);
                renderer = new PdfRenderer(pfd);
            } catch (Exception e) {
                renderer = null;
            }
        });
    }

    /** Pages visibles (pour ignorer les rendus devenus inutiles). */
    void setWanted(int from, int to) {
        wantFrom = from;
        wantTo = to;
    }

    void setBaseScale(float s) {
        if (s <= 0) return;
        if (Math.abs(s - baseScale) / baseScale < 0.08f && base.size() > 0) return;
        baseScale = s;
        baseScaleV = s;
        base.evictAll();
    }

    Bitmap base(int page) {
        return base.get(page);
    }

    Detail detail(int page) {
        return details.get(page);
    }

    void requestBase(int page) {
        if (closed || page < 0 || page >= doc.pages.size()) return;
        if (pending.contains(page) || failed.contains(page) || base.get(page) != null) return;
        NoteDoc.PageSpec sp = doc.pages.get(page);
        if (sp.pdfIndex < 0) return;
        pending.add(page);
        final float s = baseScale;
        final int pdfIdx = sp.pdfIndex;
        final float w = sp.w, h = sp.h;
        exec.execute(() -> {
            Bitmap b = null;
            boolean error = false;
            boolean wanted = page >= wantFrom - 2 && page <= wantTo + 2 && s == baseScaleV;
            if (wanted && !closed) {
                try {
                    b = renderRegion(pdfIdx, new RectF(0, 0, w, h), s);
                    if (b == null) error = true;
                } catch (OutOfMemoryError oom) {
                    main.post(base::evictAll);
                } catch (Exception e) {
                    error = true;
                }
            }
            final Bitmap fb = b;
            final boolean ferr = error;
            main.post(() -> {
                pending.remove(page);
                if (closed) return;
                if (ferr) failed.add(page);
                if (fb != null && s == baseScale) {
                    base.put(page, fb);
                    listener.onRendered();
                }
            });
        });
    }

    void clearDetails() {
        detailGen++;
        details.clear();
    }

    void requestDetails(List<DetailReq> reqs, float scale) {
        if (closed) return;
        final int gen = ++detailGen;
        // oublie les détails des pages qui ne sont plus visibles
        HashSet<Integer> keep = new HashSet<>();
        for (DetailReq r : reqs) keep.add(r.page);
        for (int i = details.size() - 1; i >= 0; i--) {
            if (!keep.contains(details.keyAt(i))) details.removeAt(i);
        }
        final ArrayList<DetailReq> copy = new ArrayList<>(reqs);
        exec.execute(() -> {
            for (DetailReq r : copy) {
                if (gen != detailGen || closed) return;
                Bitmap b;
                try {
                    b = renderRegion(r.pdfIndex, r.rect, scale);
                } catch (Throwable t) {
                    b = null;
                }
                if (b == null) continue;
                final Detail d = new Detail(r.page, r.rect, b);
                main.post(() -> {
                    if (closed || gen != detailGen) return;
                    details.put(d.page, d);
                    listener.onRendered();
                });
            }
        });
    }

    /** Thread de rendu uniquement. */
    private Bitmap renderRegion(int pdfIdx, RectF r, float s) {
        if (renderer == null || pdfIdx >= renderer.getPageCount()) return null;
        int bw = Math.round(r.width() * s);
        int bh = Math.round(r.height() * s);
        if (bw <= 0 || bh <= 0 || (long) bw * bh > 24_000_000L) return null;
        Bitmap b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        b.eraseColor(Color.WHITE);
        Matrix m = new Matrix();
        m.setTranslate(-r.left, -r.top);
        m.postScale(s, s);
        PdfRenderer.Page p = renderer.openPage(pdfIdx);
        try {
            p.render(b, null, m, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        } finally {
            p.close();
        }
        return b;
    }

    void close() {
        closed = true;
        detailGen++;
        exec.execute(() -> {
            try { if (renderer != null) renderer.close(); } catch (Exception ignored) {}
            try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
            renderer = null;
        });
        exec.shutdown();
    }
}
