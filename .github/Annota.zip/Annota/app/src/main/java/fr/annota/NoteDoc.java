package fr.annota;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Un document = un dossier "Nom.note" contenant :
 *   info.txt   (liste des pages)
 *   source.pdf (si PDF importé)
 *   ink.bin    (annotations)
 *   thumb.png  (miniature)
 */
final class NoteDoc {
    static final String EXT = ".note";
    static final float A4_W = 595.28f;
    static final float A4_H = 841.89f;

    static final class PageSpec {
        final int pdfIndex; // -1 = page vierge
        final float w, h;   // en points

        PageSpec(int pdfIndex, float w, float h) {
            this.pdfIndex = pdfIndex;
            this.w = w;
            this.h = h;
        }
    }

    final File dir;
    final ArrayList<PageSpec> pages = new ArrayList<>();

    NoteDoc(File dir) { this.dir = dir; }

    File pdf() { return new File(dir, "source.pdf"); }
    File ink() { return new File(dir, "ink.bin"); }
    File info() { return new File(dir, "info.txt"); }
    File thumb() { return new File(dir, "thumb.png"); }

    boolean hasPdf() { return pdf().exists(); }

    String name() { return displayName(dir); }

    static String displayName(File f) {
        String n = f.getName();
        return n.endsWith(EXT) ? n.substring(0, n.length() - EXT.length()) : n;
    }

    static boolean isNote(File f) {
        return f.isDirectory() && f.getName().endsWith(EXT);
    }

    long lastModified() {
        long m = dir.lastModified();
        m = Math.max(m, ink().lastModified());
        m = Math.max(m, info().lastModified());
        return m;
    }

    static NoteDoc load(File dir) throws IOException {
        NoteDoc d = new NoteDoc(dir);
        File info = d.info();
        if (info.exists()) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(info), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String[] t = line.trim().split("\\s+");
                    try {
                        if (t.length >= 5 && t[0].equals("page") && t[1].equals("pdf")) {
                            d.pages.add(new PageSpec(Integer.parseInt(t[2]), Float.parseFloat(t[3]), Float.parseFloat(t[4])));
                        } else if (t.length >= 4 && t[0].equals("page") && t[1].equals("blank")) {
                            d.pages.add(new PageSpec(-1, Float.parseFloat(t[2]), Float.parseFloat(t[3])));
                        }
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
        if (d.pages.isEmpty()) d.pages.add(new PageSpec(-1, A4_W, A4_H));
        return d;
    }

    void saveInfo() throws IOException {
        File tmp = new File(dir, "info.txt.tmp");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
            w.write("annota 1\n");
            for (PageSpec p : pages) {
                if (p.pdfIndex >= 0) {
                    w.write(String.format(Locale.US, "page pdf %d %.3f %.3f\n", p.pdfIndex, p.w, p.h));
                } else {
                    w.write(String.format(Locale.US, "page blank %.3f %.3f\n", p.w, p.h));
                }
            }
        }
        if (!tmp.renameTo(info())) throw new IOException("impossible d'enregistrer info.txt");
    }

    static String sanitize(String name) {
        if (name == null) name = "";
        name = name.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]", "_").trim();
        while (name.startsWith(".")) name = name.substring(1);
        if (name.isEmpty()) name = "Sans titre";
        if (name.length() > 120) name = name.substring(0, 120);
        return name;
    }

    /** Fichier/dossier inexistant dans parent : "Nom.ext", "Nom (2).ext", ... */
    static File uniqueChild(File parent, String base, String ext) {
        base = sanitize(base);
        File f = new File(parent, base + ext);
        int i = 2;
        while (f.exists()) {
            f = new File(parent, base + " (" + i + ")" + ext);
            i++;
        }
        return f;
    }

    static NoteDoc createBlank(File parent, String name) throws IOException {
        File dir = uniqueChild(parent, name, EXT);
        if (!dir.mkdirs()) throw new IOException("impossible de créer la note");
        NoteDoc d = new NoteDoc(dir);
        d.pages.add(new PageSpec(-1, A4_W, A4_H));
        d.saveInfo();
        return d;
    }

    static void deleteRecursive(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRecursive(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }
}
