package fr.annota;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Toutes les annotations d'un document + historique annuler / rétablir. */
final class Ink {
    private static final int MAGIC = 0x414E4B31; // "ANK1"
    private static final int VERSION = 1;
    private static final int MAX_UNDO = 300;

    static final class Edit {
        final ArrayList<Stroke> removed = new ArrayList<>();
        final ArrayList<Stroke> added = new ArrayList<>();

        boolean isEmpty() { return removed.isEmpty() && added.isEmpty(); }
    }

    private final ArrayList<ArrayList<Stroke>> pages = new ArrayList<>();
    private final ArrayDeque<Edit> undo = new ArrayDeque<>();
    private final ArrayDeque<Edit> redo = new ArrayDeque<>();

    void ensure(int count) {
        while (pages.size() < count) pages.add(new ArrayList<>());
    }

    int pageCount() { return pages.size(); }

    ArrayList<Stroke> page(int i) {
        ensure(i + 1);
        return pages.get(i);
    }

    void add(Stroke s) { page(s.page).add(s); }

    boolean remove(Stroke s) {
        if (s.page >= pages.size()) return false;
        return pages.get(s.page).remove(s);
    }

    void push(Edit e) {
        if (e == null || e.isEmpty()) return;
        undo.push(e);
        while (undo.size() > MAX_UNDO) undo.removeLast();
        redo.clear();
    }

    boolean canUndo() { return !undo.isEmpty(); }
    boolean canRedo() { return !redo.isEmpty(); }

    Edit undo() {
        Edit e = undo.poll();
        if (e == null) return null;
        for (Stroke s : e.added) remove(s);
        for (Stroke s : e.removed) add(s);
        redo.push(e);
        return e;
    }

    Edit redo() {
        Edit e = redo.poll();
        if (e == null) return null;
        for (Stroke s : e.removed) remove(s);
        for (Stroke s : e.added) add(s);
        undo.push(e);
        return e;
    }

    /** Copie des références (les traits sont immuables) pour sauvegarder en arrière-plan. */
    ArrayList<Stroke> snapshot() {
        ArrayList<Stroke> all = new ArrayList<>();
        for (ArrayList<Stroke> p : pages) all.addAll(p);
        return all;
    }

    void load(File f) throws IOException {
        if (!f.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f), 1 << 16))) {
            if (in.readInt() != MAGIC) throw new IOException("format inconnu");
            int version = in.readInt();
            if (version > VERSION) throw new IOException("version trop récente");
            int count = in.readInt();
            for (int i = 0; i < count; i++) add(Stroke.read(in));
        }
    }

    static void save(File f, List<Stroke> all) throws IOException {
        File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
        try (FileOutputStream fos = new FileOutputStream(tmp);
             DataOutputStream out = new DataOutputStream(new BufferedOutputStream(fos, 1 << 16))) {
            out.writeInt(MAGIC);
            out.writeInt(VERSION);
            out.writeInt(all.size());
            for (Stroke s : all) s.write(out);
            out.flush();
            fos.getFD().sync();
        }
        if (!tmp.renameTo(f)) {
            throw new IOException("impossible d'enregistrer " + f.getName());
        }
    }
}
