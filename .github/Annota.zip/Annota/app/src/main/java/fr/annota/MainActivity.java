package fr.annota;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Page d'accueil : arborescence de dossiers et de documents avec miniatures. */
public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 1;
    private static final int REQ_EXPORT = 2;

    private File root, current;
    private GridView grid;
    private TextView titleView, pathView, emptyView;
    private ImageView backBtn;
    private final ArrayList<Entry> entries = new ArrayList<>();
    private final Adapter adapter = new Adapter();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService thumbs = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> thumbCache = new LruCache<String, Bitmap>(32 * 1024 * 1024) {
        @Override
        protected int sizeOf(String k, Bitmap b) {
            return b.getByteCount();
        }
    };
    private NoteDoc pendingExport;

    private static final class Entry {
        File file;
        boolean folder;
        String name;
        long modified;
        int count;
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        root = new File(getFilesDir(), "Bibliotheque");
        //noinspection ResultOfMethodCallIgnored
        root.mkdirs();
        current = root;
        if (state != null) {
            String d = state.getString("dir");
            if (d != null && new File(d).isDirectory() && d.startsWith(root.getAbsolutePath())) current = new File(d);
        }
        buildUi();
        handleIntent(getIntent());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("dir", current.getAbsolutePath());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        // la miniature du document qu'on vient de fermer est écrite en arrière-plan
        main.postDelayed(this::refresh, 1200);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    /** PDF ouvert depuis une autre appli ("Ouvrir avec" / "Partager"). */
    private void handleIntent(Intent i) {
        if (i == null) return;
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) {
            uri = i.getData();
        } else if (Intent.ACTION_SEND.equals(i.getAction())) {
            //noinspection deprecation
            uri = i.getParcelableExtra(Intent.EXTRA_STREAM);
        }
        if (uri != null) {
            ArrayList<Uri> l = new ArrayList<>();
            l.add(uri);
            importUris(l, true);
            i.setAction(Intent.ACTION_MAIN);
        }
    }

    // =====================================================================================
    // Interface
    // =====================================================================================

    private void buildUi() {
        LinearLayout rootL = new LinearLayout(this);
        rootL.setOrientation(LinearLayout.VERTICAL);
        rootL.setBackgroundColor(Ui.BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 16);
        header.setPadding(p, p, p, Ui.dp(this, 8));

        backBtn = Ui.iconButton(this, Icon.BACK, "Dossier parent");
        backBtn.setOnClickListener(v -> goUp());
        header.addView(backBtn);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titleView = Ui.text(this, "Annota", 28, Ui.TEXT, true);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        pathView = Ui.text(this, "", 13, Ui.SUB, false);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.START);
        titles.addView(titleView);
        titles.addView(pathView);
        titles.setPadding(Ui.dp(this, 6), 0, 0, 0);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        rootL.addView(header);

        // Boutons d'action
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(p, 0, p, Ui.dp(this, 8));
        View imp = Ui.pill(this, Icon.IMPORT, "Importer un PDF", true);
        imp.setOnClickListener(v -> pickPdf());
        View note = Ui.pill(this, Icon.NOTE, "Nouvelle note", false);
        note.setOnClickListener(v -> newNote());
        View folder = Ui.pill(this, Icon.NEW_FOLDER, "Nouveau dossier", false);
        folder.setOnClickListener(v -> newFolder());
        for (View v : new View[]{imp, note, folder}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(this, 10);
            actions.addView(v, lp);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(actions);
        rootL.addView(hs);

        FrameLayout body = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setColumnWidth(Ui.dp(this, 168));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setVerticalSpacing(Ui.dp(this, 14));
        grid.setHorizontalSpacing(Ui.dp(this, 14));
        grid.setPadding(p, Ui.dp(this, 8), p, p);
        grid.setClipToPadding(false);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(0));
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, v, pos, id) -> open(entries.get(pos)));
        grid.setOnItemLongClickListener((parent, v, pos, id) -> {
            showItemMenu(entries.get(pos));
            return true;
        });
        body.addView(grid);
        emptyView = Ui.text(this, "Ce dossier est vide.\nImportez un PDF ou créez une note.", 16, Ui.SUB, false);
        emptyView.setGravity(Gravity.CENTER);
        body.addView(emptyView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rootL.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Ui.applyInsets(rootL);
        Ui.lightBars(this);
        setContentView(rootL);
    }

    private void refresh() {
        boolean atRoot = current.equals(root);
        backBtn.setVisibility(atRoot ? View.GONE : View.VISIBLE);
        titleView.setText(atRoot ? "Annota" : current.getName());
        StringBuilder sb = new StringBuilder("Bibliothèque");
        if (!atRoot) {
            String rel = current.getAbsolutePath().substring(root.getAbsolutePath().length());
            for (String part : rel.split("/")) if (!part.isEmpty()) sb.append("  ›  ").append(part);
        }
        pathView.setText(sb.toString());

        entries.clear();
        File[] kids = current.listFiles();
        ArrayList<Entry> folders = new ArrayList<>(), notes = new ArrayList<>();
        if (kids != null) {
            for (File f : kids) {
                if (!f.isDirectory()) continue;
                Entry e = new Entry();
                e.file = f;
                if (NoteDoc.isNote(f)) {
                    e.folder = false;
                    e.name = NoteDoc.displayName(f);
                    e.modified = new NoteDoc(f).lastModified();
                    notes.add(e);
                } else {
                    e.folder = true;
                    e.name = f.getName();
                    e.modified = f.lastModified();
                    String[] l = f.list();
                    e.count = l == null ? 0 : l.length;
                    folders.add(e);
                }
            }
        }
        final Collator coll = Collator.getInstance(Locale.FRANCE);
        folders.sort((a, b) -> coll.compare(a.name, b.name));
        notes.sort((a, b) -> Long.compare(b.modified, a.modified));
        entries.addAll(folders);
        entries.addAll(notes);
        adapter.notifyDataSetChanged();
        emptyView.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void goUp() {
        if (!current.equals(root)) {
            current = current.getParentFile();
            refresh();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (!current.equals(root)) goUp();
        else super.onBackPressed();
    }

    private void open(Entry e) {
        if (e.folder) {
            current = e.file;
            refresh();
        } else {
            openNote(e.file);
        }
    }

    private void openNote(File dir) {
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra(EditorActivity.EXTRA_DIR, dir.getAbsolutePath());
        startActivity(i);
    }

    // =====================================================================================
    // Création / import
    // =====================================================================================

    private interface TextCallback { void on(String s); }

    private void prompt(String title, String initial, String ok, TextCallback cb) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        et.setText(initial);
        et.selectAll();
        FrameLayout f = new FrameLayout(this);
        int p = Ui.dp(this, 20);
        f.setPadding(p, Ui.dp(this, 8), p, 0);
        f.addView(et);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(f)
                .setPositiveButton(ok, (dlg, w) -> {
                    String s = et.getText().toString().trim();
                    if (!s.isEmpty()) cb.on(s);
                })
                .setNegativeButton("Annuler", null)
                .create();
        d.show();
        et.requestFocus();
    }

    private void newFolder() {
        prompt("Nouveau dossier", "", "Créer", name -> {
            File f = NoteDoc.uniqueChild(current, name, "");
            if (!f.mkdirs()) toast("Impossible de créer le dossier");
            refresh();
        });
    }

    private void newNote() {
        String def = "Note du " + new SimpleDateFormat("d MMM yyyy", Locale.FRANCE).format(new Date());
        prompt("Nouvelle note", def, "Créer", name -> {
            try {
                NoteDoc d = NoteDoc.createBlank(current, name);
                refresh();
                openNote(d.dir);
            } catch (IOException e) {
                toast("Impossible de créer la note");
            }
        });
    }

    private void pickPdf() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, REQ_IMPORT);
        } catch (Exception e) {
            toast("Aucun gestionnaire de fichiers disponible");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == REQ_IMPORT) {
            ArrayList<Uri> uris = new ArrayList<>();
            ClipData cd = data.getClipData();
            if (cd != null) {
                for (int i = 0; i < cd.getItemCount(); i++) uris.add(cd.getItemAt(i).getUri());
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
            importUris(uris, uris.size() == 1);
        } else if (req == REQ_EXPORT && data.getData() != null && pendingExport != null) {
            final NoteDoc d = pendingExport;
            final Uri uri = data.getData();
            pendingExport = null;
            toast("Export en cours…");
            io.execute(() -> {
                String msg;
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out == null) throw new IOException("destination illisible");
                    DocIO.export(d, DocIO.loadStrokes(d), out);
                    msg = "PDF exporté ✔";
                } catch (Exception | OutOfMemoryError e) {
                    msg = "Échec de l'export : " + e.getMessage();
                }
                final String m = msg;
                main.post(() -> toast(m));
            });
        }
    }

    private void importUris(List<Uri> uris, boolean openAfter) {
        if (uris.isEmpty()) return;
        toast(uris.size() > 1 ? "Import de " + uris.size() + " PDF…" : "Import du PDF…");
        final File target = current;
        io.execute(() -> {
            File last = null;
            int ok = 0;
            for (Uri u : uris) {
                try {
                    last = DocIO.importPdf(this, u, target);
                    ok++;
                } catch (Exception | OutOfMemoryError e) {
                    final String m = "Import impossible : " + e.getMessage();
                    main.post(() -> toast(m));
                }
            }
            final File open = openAfter && ok == 1 ? last : null;
            final int count = ok;
            main.post(() -> {
                refresh();
                if (open != null) openNote(open);
                else if (count > 1) toast(count + " PDF importés");
            });
        });
    }

    // =====================================================================================
    // Menu d'un élément (appui long)
    // =====================================================================================

    private void showItemMenu(Entry e) {
        final String[] items = e.folder
                ? new String[]{"Renommer", "Déplacer…", "Supprimer"}
                : new String[]{"Renommer", "Déplacer…", "Exporter en PDF annoté…", "Supprimer"};
        new AlertDialog.Builder(this)
                .setTitle(e.name)
                .setItems(items, (d, which) -> {
                    String it = items[which];
                    if (it.startsWith("Renommer")) rename(e);
                    else if (it.startsWith("Déplacer")) move(e);
                    else if (it.startsWith("Exporter")) export(e);
                    else if (it.startsWith("Supprimer")) delete(e);
                })
                .show();
    }

    private void rename(Entry e) {
        prompt("Renommer", e.name, "Renommer", name -> {
            File parent = e.file.getParentFile();
            File dst = NoteDoc.uniqueChild(parent, name, e.folder ? "" : NoteDoc.EXT);
            if (!e.file.renameTo(dst)) toast("Impossible de renommer");
            refresh();
        });
    }

    private void collectFolders(File dir, int depth, File exclude, List<File> out, List<String> labels) {
        if (dir.equals(exclude)) return;
        out.add(dir);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < depth; i++) sb.append("      ");
        sb.append(depth == 0 ? "Bibliothèque" : "📁 " + dir.getName());
        labels.add(sb.toString());
        File[] kids = dir.listFiles();
        if (kids == null) return;
        ArrayList<File> sub = new ArrayList<>();
        for (File k : kids) if (k.isDirectory() && !NoteDoc.isNote(k)) sub.add(k);
        final Collator coll = Collator.getInstance(Locale.FRANCE);
        sub.sort((a, b) -> coll.compare(a.getName(), b.getName()));
        for (File k : sub) collectFolders(k, depth + 1, exclude, out, labels);
    }

    private void move(Entry e) {
        final ArrayList<File> dirs = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();
        collectFolders(root, 0, e.folder ? e.file : null, dirs, labels);
        new AlertDialog.Builder(this)
                .setTitle("Déplacer « " + e.name + " » vers")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    File target = dirs.get(which);
                    if (target.equals(e.file.getParentFile())) return;
                    File dst = NoteDoc.uniqueChild(target, e.name, e.folder ? "" : NoteDoc.EXT);
                    if (!e.file.renameTo(dst)) toast("Impossible de déplacer");
                    refresh();
                })
                .show();
    }

    private void export(Entry e) {
        try {
            pendingExport = NoteDoc.load(e.file);
        } catch (IOException ex) {
            toast("Document illisible");
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_TITLE, e.name + " (annoté).pdf");
        try {
            startActivityForResult(i, REQ_EXPORT);
        } catch (Exception ex) {
            toast("Aucune application pour enregistrer le fichier");
        }
    }

    private void delete(Entry e) {
        String msg = e.folder
                ? "Le dossier « " + e.name + " » et tout son contenu seront supprimés définitivement."
                : "« " + e.name + " » et ses annotations seront supprimés définitivement.";
        new AlertDialog.Builder(this)
                .setTitle("Supprimer ?")
                .setMessage(msg)
                .setPositiveButton("Supprimer", (d, w) -> {
                    NoteDoc.deleteRecursive(e.file);
                    refresh();
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        io.shutdown();
        thumbs.shutdownNow();
        super.onDestroy();
    }

    // =====================================================================================
    // Grille
    // =====================================================================================

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return entries.size(); }
        @Override public Object getItem(int i) { return entries.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            Cell cell;
            if (convert == null) {
                cell = new Cell();
                convert = cell.build();
            } else {
                cell = (Cell) convert.getTag();
            }
            cell.bind(entries.get(pos));
            return convert;
        }
    }

    private final class Cell {
        LinearLayout rootV;
        FrameLayout frame;
        ImageView image;
        TextView name, sub;

        View build() {
            rootV = new LinearLayout(MainActivity.this);
            rootV.setOrientation(LinearLayout.VERTICAL);
            int p = Ui.dp(MainActivity.this, 6);
            rootV.setPadding(p, p, p, p);
            Ui.ripple(rootV, 0x00000000, Ui.dp(MainActivity.this, 14));

            frame = new FrameLayout(MainActivity.this);
            frame.setBackground(Ui.roundStroke(0xFFFFFFFF, 0xFFDADADF, Ui.dp(MainActivity.this, 1), Ui.dp(MainActivity.this, 10)));
            frame.setClipToOutline(true);
            image = new ImageView(MainActivity.this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            frame.addView(image, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            rootV.addView(frame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(MainActivity.this, 200)));

            name = Ui.text(MainActivity.this, "", 15, Ui.TEXT, true);
            name.setMaxLines(2);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER_HORIZONTAL);
            name.setPadding(0, Ui.dp(MainActivity.this, 8), 0, 0);
            rootV.addView(name);
            sub = Ui.text(MainActivity.this, "", 12, Ui.SUB, false);
            sub.setGravity(Gravity.CENTER_HORIZONTAL);
            rootV.addView(sub);
            rootV.setTag(this);
            return rootV;
        }

        void bind(Entry e) {
            name.setText(e.name);
            if (e.folder) {
                frame.setBackground(Ui.round(0xFFE8EEFF, Ui.dp(MainActivity.this, 10)));
                image.setTag(null);
                image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                image.setImageDrawable(new IconSized(Icon.FOLDER, Ui.ACCENT, Ui.dp(MainActivity.this, 72)));
                sub.setText(e.count <= 1 ? e.count + " élément" : e.count + " éléments");
            } else {
                frame.setBackground(Ui.roundStroke(0xFFFFFFFF, 0xFFDADADF, Ui.dp(MainActivity.this, 1), Ui.dp(MainActivity.this, 10)));
                image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                sub.setText(new SimpleDateFormat("d MMM yyyy, HH:mm", Locale.FRANCE).format(new Date(e.modified)));
                File t = new File(e.file, "thumb.png");
                final String key = t.getAbsolutePath() + ":" + t.lastModified();
                image.setTag(key);
                Bitmap cached = thumbCache.get(key);
                if (cached != null) {
                    image.setImageBitmap(cached);
                } else {
                    image.setImageDrawable(null);
                    if (t.exists()) {
                        final ImageView iv = image;
                        thumbs.execute(() -> {
                            Bitmap b = BitmapFactory.decodeFile(t.getAbsolutePath());
                            if (b == null) return;
                            main.post(() -> {
                                thumbCache.put(key, b);
                                if (key.equals(iv.getTag())) iv.setImageBitmap(b);
                            });
                        });
                    }
                }
            }
        }
    }

    /** Icône avec une taille intrinsèque (pour les dossiers dans la grille). */
    private static final class IconSized extends android.graphics.drawable.LayerDrawable {
        private final int size;

        IconSized(int type, int color, int size) {
            super(new android.graphics.drawable.Drawable[]{new Icon(type, color)});
            this.size = size;
        }

        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
    }
}
