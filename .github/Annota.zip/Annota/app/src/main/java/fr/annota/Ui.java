package fr.annota;

import android.app.Activity;
import android.content.Context;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int ACCENT = 0xFF2962FF;
    static final int ACCENT_SOFT = 0x262962FF;
    static final int BG = 0xFFF2F2F7;
    static final int TEXT = 0xFF1C1C1E;
    static final int SUB = 0xFF8E8E93;
    static final int SURFACE = 0xFFFFFFFF;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static GradientDrawable roundStroke(int fill, int strokeColor, int strokePx, float radiusPx) {
        GradientDrawable g = round(fill, radiusPx);
        g.setStroke(strokePx, strokeColor);
        return g;
    }

    static void ripple(View v, int bgColor, float radiusPx) {
        v.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22000000), round(bgColor, radiusPx),
                round(0xFFFFFFFF, radiusPx)));
    }

    /** Android 15 dessine sous les barres système : on rajoute la marge nécessaire. */
    static void applyInsets(View root) {
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                v.setPadding(i.left, i.top, i.right, i.bottom);
                return WindowInsets.CONSUMED;
            } else {
                //noinspection deprecation
                v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
                //noinspection deprecation
                return insets.consumeSystemWindowInsets();
            }
        });
    }

    static void lightBars(Activity a) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = a.getWindow().getInsetsController();
            if (c != null) {
                int f = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(f, f);
            }
        }
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static ImageButton iconButton(Context c, int icon, String desc) {
        ImageButton b = new ImageButton(c);
        b.setImageDrawable(new Icon(icon, TEXT));
        b.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int p = dp(c, 10);
        b.setPadding(p, p, p, p);
        ripple(b, 0x00000000, dp(c, 12));
        b.setContentDescription(desc);
        b.setTooltipText(desc);
        int s = dp(c, 46);
        b.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return b;
    }

    /** Bouton "pilule" avec icône + texte. */
    static LinearLayout pill(Context c, int icon, String label, boolean primary) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        int ph = dp(c, 14), pv = dp(c, 8);
        l.setPadding(ph, pv, ph + dp(c, 4), pv);
        int fg = primary ? 0xFFFFFFFF : ACCENT;
        ripple(l, primary ? ACCENT : ACCENT_SOFT, dp(c, 20));
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(new Icon(icon, fg));
        int s = dp(c, 22);
        l.addView(iv, new LinearLayout.LayoutParams(s, s));
        TextView t = text(c, label, 15, fg, true);
        t.setPadding(dp(c, 6), 0, 0, 0);
        l.addView(t);
        l.setClickable(true);
        l.setFocusable(true);
        return l;
    }
}
