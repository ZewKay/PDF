plugins {
    id("com.android.application")
}

android {
    namespace = "fr.annota"
    compileSdk = 35

    defaultConfig {
        applicationId = "fr.annota"
        minSdk = 29
        targetSdk = 35
        // Le numéro de version augmente à chaque compilation GitHub : les mises à jour s'installent par-dessus.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    // Clé de signature fixe : chaque nouvelle version s'installe par-dessus l'ancienne
    // sans perdre tes notes.
    signingConfigs {
        create("perso") {
            storeFile = file("annota.keystore")
            storePassword = "annota123"
            keyAlias = "annota"
            keyPassword = "annota123"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("perso")
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("perso")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
